import { TABLE_PAGE } from "src/constants";
import { ReportActivityRequest } from "src/models/activtity";
import { client } from "./apiConfig";

export default {
  async reportActivityOfStore(params: ReportActivityRequest, page = TABLE_PAGE.PAGE + 1, size = TABLE_PAGE.SIZE) {
    const url = `/admin/activity?page=${page}&size=${size}`
    const res = await client.post(url, params)
    return res
  },
  async getAllActivity(storeId: number, fromTime: string, toTime: string) {
    const url = `/admin/activity?drg_store_id=${storeId}&from_time=${fromTime}&to_time=${toTime}`
    const res = await client.get(url)
    return res
  }
}