import auth from './authApi';
import store from './store';
import account from './account';
import activity from './activity';
import company from './company';
import smsCompany from './smsCompany';
import wallet from './wallet';
import smsTemplate from './smsTemplate';
import category from './category';

export default {
    auth,
    activity,
    store,
    account,
    company,
    smsCompany,
    wallet,
    smsTemplate,
    category,
}