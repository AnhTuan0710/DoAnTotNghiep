import { SmsTemplateData } from './../models/smsTemplate';
import { client } from './apiConfig';
export default {
	createSmsTemplate(data: SmsTemplateData) {
		const url = `/sms/template`;
		return client.post(url, data).then((response) => response);
	}
}