import { TABLE_PAGE } from "src/constants";
import { SmsCashflow, SmsPriceListRequest, SmsCompanySearch } from "src/models/smsCompany";
import { client } from "./apiConfig";
export default {
  getAllSmsCompany(data: SmsCompanySearch, page = TABLE_PAGE.PAGE + 1, size = TABLE_PAGE.SIZE) {
    const url = `/sms/company/search?page=${page}&size=${size}`;
    return client
      .post(url, data)
      .then(response => {
        return response;
      });
  },
  getBrandOfCompany(refCompanyId: number) {
    const url = `/sms/brand-name/${refCompanyId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
  getZaloOfCompany(refCompanyId: number) {
    const url = `/sms/zalo/${refCompanyId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
  getListPriceOfCompany(refCompanyId: number) {
    const url = `/sms/price/${refCompanyId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
  getListCashFlowOfCompany(data: SmsCashflow, refCompanyId: number, page = TABLE_PAGE.PAGE + 1, size = TABLE_PAGE.SIZE) {
    const url = `/sms/cashflow/${refCompanyId}?page=${page}&size=${size}`;
    return client
      .post(url, data)
      .then(response => {
        return response;
      });
  },
  updateListPrice(data: SmsPriceListRequest) {
    const url = `/sms/price`;
    return client
      .post(url, data,)
      .then(response => {
        return response;
      });
  },
  getListSmsTemplate(refCompanyId: number) {
    const url = `/sms/template/${refCompanyId}`;
    return client.get(url)
  },
  deleteSmsTemplate(templateId: number) {
    const url = `/sms/template/${templateId}`;
    return client.delete(url)
  },
};