import { RechargeWalletRequest } from "src/models/wallet";
import { client } from "./apiConfig";
export default {
  rechargeWallet(data: RechargeWalletRequest) {
    const url = `/sms/wallet/admin/recharge`;
    return client
      .post(url, data,)
      .then(response => {
        return response;
      });
  },
  getWalletOfCompany(refCompanyId: number) {
    const url = `/sms/wallet/${refCompanyId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
};