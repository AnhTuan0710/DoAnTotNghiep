import { CreateStoreType, AccountDelete, AccountSearch } from "src/models/account";
import { client } from "./apiConfig";
export default {
  getAllAccountInStore(drugStoreId: number) {
    const url = `/admin/account?drg_store_id=${drugStoreId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
  deleteAccount(data: AccountDelete) {
    const url = `/admin/account/info`;
    return client
      .put(url, data)
      .then(response => {
        return response;
      });
  },
  createAccount(data: CreateStoreType) {
    const url = `/oauth/admin/store`;
    return client
      .post(url, data)
      .then(response => {
        return response;
      });
  }
};