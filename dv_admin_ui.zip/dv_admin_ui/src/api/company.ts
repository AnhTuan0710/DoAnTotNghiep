import { TABLE_PAGE } from "src/constants";
import { CompanySearch } from "src/models/company";
import { client } from "./apiConfig";
export default {
  getAllCompany(data: CompanySearch, page = TABLE_PAGE.PAGE + 1, size = TABLE_PAGE.SIZE) {
    const url = `/admin/company/search?page=${page}&size=${size}`;
    return client
      .post(url, data)
      .then(response => {
        return response;
      });
  }
};