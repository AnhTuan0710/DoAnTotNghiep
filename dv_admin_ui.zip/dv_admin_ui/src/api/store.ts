import { TABLE_PAGE } from 'src/constants';
import { RenewStore, StoreSearch, UpgradePackageType, } from 'src/models/store';
import { client } from "./apiConfig";
export default {
  getAllStore(data: StoreSearch, page = TABLE_PAGE.PAGE + 1, size = TABLE_PAGE.SIZE) {
    const url = `/admin/store/search?page=${page}&size=${size}`;
    return client
      .post(url, data)
      .then(response => {
        return response;
      });
  },
  renewStore(data: RenewStore) {
    const url = `/admin/store`;
    return client
      .put(url, data)
      .then(response => {
        return response;
      });
  },
  getAllStoreInCompany(companyId: number) {
    const url = `/admin/store?company_id=${companyId}`;
    return client
      .get(url)
      .then(response => {
        return response;
      });
  },
  deleteStore(drgStoreId: number) {
    const url = `/admin/store?drg_store_id=${drgStoreId}`;
    return client
      .delete(url)
      .then(response => {
        return response;
      });
  },
  getStoreLicense(drgStoreId: number) {
    const url = `/pharmacy/store/license/admin?drg_store_id=${drgStoreId}`
    return client.get(url)
  },

  upgradePackage(data: UpgradePackageType) {
    const url = `/pharmacy/store/license/admin`
    return client.post(url,data)
  }
};
