import { useState } from 'react';
import {
  Autocomplete,
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography
} from '@mui/material';
import AlertDialog from 'src/components/DialogConfirm';
import InputField from 'src/components/InputField';
import InputNumberField from 'src/components/InputNumberField';
import SelectField from 'src/components/SelectField/input';
import InputFieldMultiline from 'src/components/InputFieldMultiline';
import './index.scss';
import { LIST_CAMPAIGN_TYPE, LIST_TEMPLATE_PARAMS_NAME } from 'src/constants';
import { SmsBrandname } from 'src/models/smsCompany';
import { useSelector } from 'react-redux';
import { RootState } from 'src/app/store';

interface Props {
  open: boolean;
  onClose: () => void;
  handleNo: () => void;
  handleYes: (values: any) => void;
  listBrandname: SmsBrandname[];
}

const initialValues = {
  ref_channel_name: '',
  channel_code: '',
  template_name: '',
  template_type: '',
  template_content: '',
  template_params: [
    {
      id: 1,
      name: '',
      type: '',
      max_length: 0,
      is_require: 1
    }
  ]
};

export default function ModalCreateTemplate(props: Props) {
  const { open, onClose, handleNo, handleYes, listBrandname } = props;
  const [params, setParams] = useState(initialValues);
  const { user_name } = useSelector((state: RootState) => state.auth);
  
  const brandname = listBrandname.map((brand) => {
    return { value: brand.brand_name, name: brand.brand_name };
  });

  const handleChange = (e: any) => {
    setParams((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleChangeTemplateParams = (e: any, index: number) => {
    const { name, value } = e.target;
    const listTemplateParams = [...params.template_params];
    listTemplateParams[index][name] = value;
    setParams((prev) => ({ ...prev, template_params: listTemplateParams }));
  };

  const handleChangeAutoComplete = (e: any, newValue: string, index: number) => {
    const listTemplateParams = [...params.template_params];
    listTemplateParams[index]["name"] = newValue;
    setParams((prev) => ({ ...prev, template_params: listTemplateParams }));
  }

  const addTemplateParams = () => {
    setParams((prev) => ({
      ...prev,
      template_params: [
        ...prev.template_params,
        {
          id: Math.random(),
          name: '',
          type: '',
          max_length: 0,
          is_require: 1
        }
      ]
    }));
  };

  const removeTemplateParams = (index: number) => {
    setParams((prev) => ({
      ...prev,
      template_params: [...prev.template_params].filter((item) => item.id !== index)
    }));
  };

  const handleSubmit = () => {
    const templateParams = [...params.template_params].map((item) => {
      return {
        name: item.name,
        type: item.type,
        max_length: +item.max_length,
        is_require: item.is_require
      }
    });
    const values = {
      ref_company_id: listBrandname.map(item => item.ref_company_id)[0],
      ref_channel_name: params.ref_channel_name,
      channel_code: params.channel_code,
      template_name: params.template_name,
      template_type: params.template_type,
      template_content: params.template_content,
      template_params: templateParams,
      updated_user: user_name
    }
    if (values) {
      handleYes(values);
    }
  };

  const handleCancel = () => {
    setParams(initialValues);
    handleNo();
  }

  const _renderTemplateParams = () => {
    return params.template_params.map((item, index) => {
      return (
        <TableRow key={index}>
          <TableCell>
            <Autocomplete
              size='small'
              fullWidth
              freeSolo
              id="select-input"
              disableClearable
              value={item.name}
              onChange={(e, value) => handleChangeAutoComplete(e, value, index)}
              options={LIST_TEMPLATE_PARAMS_NAME.map((option) => option.name)}
              renderInput={(props) => (
                <TextField
                  {...props}
                  margin='normal'
                  label="Tên"
                  name={'name'}
                  value={item.name}
                  onChange={(e) => handleChangeTemplateParams(e, index)}
                  InputProps={{ ...props.InputProps, type: 'search' }}
                  sx={{ width: '150px' }}
                />
              )}
            />
          </TableCell>
          <TableCell>
            <SelectField
              style={{ width: '150px' }}
              name={'type'}
              label="Loại"
              value={item.type}
              onChange={(e) => handleChangeTemplateParams(e, index)}
              options={[
                { value: 'string', name: 'String' },
                { value: 'number', name: 'Number' },
                { value: 'date', name: 'Date' }
              ]}
            />
          </TableCell>
          <TableCell>
            <InputNumberField
              name={'max_length'}
              label="Max length"
              value={item.max_length as any}
              onChange={(e) => handleChangeTemplateParams(e, index)}
              style={{ width: '100px' }}
            />
          </TableCell>
          <TableCell>
            <SelectField
              style={{ width: '100px' }}
              name={'is_require'}
              label="Require"
              value={item.is_require as any}
              onChange={(e) => handleChangeTemplateParams(e, index)}
              options={[
                { value: 1, name: 'Có' },
                { value: 0, name: 'Không' }
              ]}
            />
          </TableCell>
          <TableCell>
            {item.id === 1 ? (
              <Button size="small" color="primary" onClick={() => addTemplateParams()}>Thêm</Button>
            ) : (
              <Button size="small" color="error" onClick={() => removeTemplateParams(item.id)}>Xóa</Button>
            )}
          </TableCell>
        </TableRow>
      );
    });
  };

  const _renderTable = () => {
    return (
      <>
        <Typography my={1}>Mẫu template</Typography>
        <Table sx={{ width: '100%' }}>
          <TableHead>
            <TableRow>
              <TableCell>Tên</TableCell>
              <TableCell>Loại</TableCell>
              <TableCell>Độ dài tối đa</TableCell>
              <TableCell>Bắt buộc</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {_renderTemplateParams()}
          </TableBody>
        </Table>
      </>
    );
  };

  return (
    <>
      <AlertDialog
        style={{ minWidth: '700px' }}
        title="Tạo template SMS"
        open={open}
        close={onClose}
        className="custom-dialog"
        children={
          <Box component="div">
            <Box width='100%'>
              <SelectField
                name={'channel_code'}
                label="Chanel"
                value={params.channel_code}
                onChange={handleChange}
                options={[
                  { value: 'SMS', name: 'SMS' },
                  { value: 'ZALO_OA', name: 'ZALO' }
                ]}
              />
              <SelectField
                name={'ref_channel_name'}
                label="Tên chanel"
                value={params.ref_channel_name}
                onChange={handleChange}
                options={brandname}
              />
              <InputField
                name={'template_name'}
                label="Tên template"
                value={params.template_name}
                onChange={handleChange}
              />
              <SelectField
                name={'template_type'}
                label="Loại template"
                value={params.template_type}
                onChange={handleChange}
                options={LIST_CAMPAIGN_TYPE}
              />
              <InputFieldMultiline
                name={'template_content'}
                label="Nội dung template"
                value={params.template_content}
                onChange={handleChange}
                row={4}
              />
            </Box>
            {_renderTable()}
          </Box>
        }
        handleNo={handleCancel}
        handleYes={handleSubmit}
      />
    </>
  );
}
