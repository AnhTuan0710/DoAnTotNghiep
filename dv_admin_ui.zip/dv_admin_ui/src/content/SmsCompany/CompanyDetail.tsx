import { Box } from "@mui/system"
import { useLocation, useNavigate } from "react-router"
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import api from "src/api";
import { useEffect, useState } from "react";
import moment from "moment";
import { SmsBrandname, SmsPriceList, SmsCompany, SmsZalo } from "src/models/smsCompany";
import { Alert, AlertColor, Button, LinearProgress, Snackbar, Tab, Table, TableBody, TableCell, TableHead, TableRow, Tabs } from "@mui/material";
import ModalRecharge from "./ModalRecharge";
import { MoneyFormat } from "src/utils/money";
import ModalUpdatePrice from "./ModalUpdatePrice";
import TransactionHistorty from "./TransactionHistorty";
import TabPanel from "src/components/TabPanel";
import SmsTemplate from "./SmsTemplate";

export type Notification = {
  isNoti: boolean
  notiType: AlertColor,
  notiTitle: string,
}

const initNoti: Notification = {
  isNoti: false,
  notiType: 'success',
  notiTitle: '',
}

export default function CompanyDetail() {
  const location = useLocation()
  const navigate = useNavigate()
  const [listBrandname, setListBrandname] = useState<SmsBrandname[]>([])
  const [listZaloOa, setListZaloOa] = useState<SmsZalo[]>([])
  const [wallet, setWallet] = useState()
  const [listPrice, setListPrice] = useState<SmsPriceList>()
  const [modalRechargeVisible, setModalRechargeVisible] = useState(false)
  const [modalUpdatePriceVisible, setModalUpdatePriceVisible] = useState(false)
  const [notification, setNotification] = useState<Notification>(initNoti)
  const [loading, setLoading] = useState(false)
  const [walletId, setWalletId] = useState(0)
  const [tabValue, setTabValue] = useState(0)
  const companyInfo: SmsCompany = location.state as SmsCompany

  useEffect(() => {
    getZaloOa()
    getWalletOfCompany()
    getListPriceOfCompany()
    getBranchName()
  }, [])

  const getBranchName = async () => {
    try {
      const res = await api.smsCompany.getBrandOfCompany(companyInfo.ref_company_id)
      setListBrandname(res.data)
    } catch (error) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Không lấy được danh sách Brandname!'
      })
    }
  }

  const getZaloOa = async () => {
    try {
      const res = await api.smsCompany.getZaloOfCompany(companyInfo.ref_company_id)
      setListZaloOa(res.data)
    } catch (error) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: ' Không thể lấy được danh sách Zalo Oa!'
      })
    }
  }

  const getWalletOfCompany = async () => {
    try {
      const res = await api.wallet.getWalletOfCompany(companyInfo.ref_company_id)
      setWallet(res.data.balance)
      setWalletId(res.data.wallet_id)
    } catch (error) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Không thể lấy được số dư ví!'
      })
    }
  }

  const getListPriceOfCompany = async () => {
    setLoading(true)
    try {
      const res = await api.smsCompany.getListPriceOfCompany(companyInfo.ref_company_id)
      setListPrice(res.data)
      setLoading(false)
    }
    catch (error) {
      setLoading(false)
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Không lấy được bảng giá dịch vụ!'
      })
    }
  }

  const closeNotifi = () => {
    setNotification(initNoti)
  }

  const handleGoback = () => {
    navigate('/management/sms-company')
  }

  const handleCloseModalRecharge = () => {
    setModalRechargeVisible(false)
  }

  const handleCloseModalUpdatePrice = () => {
    setModalUpdatePriceVisible(false)
  }

  const handleGetWallet = () => {
    getWalletOfCompany()
    setNotification({
      isNoti: true,
      notiType: 'success',
      notiTitle: 'Nạp tiền thành công!'
    })
  }

  const handleGetListPrice = () => {
    getListPriceOfCompany()
    setNotification({
      isNoti: true,
      notiType: 'success',
      notiTitle: 'Cập nhật giá tin nhắn thành công!'
    })
  }

  const notiErr = () => {
    setNotification({
      isNoti: true,
      notiType: 'error',
      notiTitle: 'Thất bại!'
    })
  }

  const _renderInfoItem = (title: string, property: any) => {
    return (
      <Box component='div' sx={{ display: 'flex', flexDirection: "row" }}>
        <Box component='p' sx={{ minWidth: '150px', fontWeight: 'bold' }}>{title}: </Box>
        <Box component='p'>{property}</Box>
      </Box>
    )
  }

  const _renderWallet = (title: string, property: any) => {
    return (
      <Box component='div' sx={{ display: 'flex', flexDirection: "row" }}>
        <Box component='div' sx={{ display: 'flex', flexDirection: "row", justifyContent: 'flex-start' }}>
          <Box component='p' sx={{ minWidth: '150px', fontWeight: 'bold' }}>{title}: </Box>
          <Box component='p' sx={{ color: "red", minWidth: '150px', }}>{MoneyFormat(property)} VNĐ</Box>
        </Box>
        <Button onClick={() => setModalRechargeVisible(true)}>Nạp tiền </Button>
      </Box>
    )
  }

  const _renderListBrandname = (title: string, list: SmsBrandname[]) => {
    return (
      <Box component='div' sx={{ display: 'flex', flexDirection: "row" }}>
        <Box component='p' sx={{ minWidth: '150px', fontWeight: 'bold' }}>{title}: </Box>
        {list.map((item: SmsBrandname, index: number) => {
          return (
            <Box component='p' key={index}>{item.brand_name}{index === list.length - 1 ? "" : ', '} </Box>
          )
        })}
      </Box>
    )
  }

  const _renderListZaloOa = (title: string, list: SmsZalo[]) => {
    return (
      <Box component='div' sx={{ display: 'flex', flexDirection: "row" }}>
        <Box component='p' sx={{ minWidth: '150px', fontWeight: 'bold' }}>{title}: </Box>
        {list.map((item: SmsZalo, index: number) => {
          return (
            <Box component='p' key={index} >{item.zalo_oa_name}{index === list.length - 1 ? "" : ', '} </Box>
          )
        })}
      </Box>
    )
  }

  const _renderCompanyDetail = () => {
    return (
      <Box component='div' sx={{ margin: '0px 10px', backgroundColor: '#fff', borderRadius: '5px', padding: '10px' }}>
        <Box component='div' sx={{ display: 'flex', flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <Box component='h3' sx={{ margin: "0px" }}>Thông tin công ty</Box>
        </Box>
        <Box component='div' sx={{ display: 'flex', flexDirection: 'row' }}>
          <Box component='div' sx={{ padding: '0px', width: '50%' }}>
            {_renderInfoItem('Tên công ty', companyInfo.company_name)}
            {_renderInfoItem('Loại công ty', companyInfo.company_type)}
            {_renderInfoItem('Số điện thoại', companyInfo.phone_no)}
            {_renderInfoItem('Email', companyInfo.email)}
          </Box>
          <Box component='div' sx={{ padding: '0px', width: '50%' }}>
            {_renderInfoItem('Ngày đăng kí', moment(companyInfo.created_date).format("DD/MM/YYYY"))}
            {_renderInfoItem('Trạng thái', 'Đang hoạt động')}
            {_renderListBrandname('Brandname sở hữu', listBrandname)}
            {_renderListZaloOa('Zalo Oa sở hữu', listZaloOa)}
            {_renderWallet('Số dư ví', wallet)}
          </Box>
        </Box>
      </Box>

    )
  }

  const _renderPriceAds = () => {
    return (
      <TableRow>
        <TableCell>Quảng cáo</TableCell>
        <TableCell>{listPrice.price_ads_mobi}</TableCell>
        <TableCell>{listPrice.price_ads_vina}</TableCell>
        <TableCell>{listPrice.price_ads_viettel}</TableCell>
        <TableCell>{listPrice.price_ads_vietnam}</TableCell>
        <TableCell>{listPrice.price_ads_gmobile}</TableCell>
        <TableCell>Không áp dụng</TableCell>
        <TableCell>{listPrice.price_cs_zalo}</TableCell>
      </TableRow>
    )
  }

  const _renderPriceCs = () => {
    return (
      <TableRow>
        <TableCell>CSKH</TableCell>
        <TableCell>{listPrice.price_cs_mobi}</TableCell>
        <TableCell>{listPrice.price_cs_vina}</TableCell>
        <TableCell>{listPrice.price_cs_viettel}</TableCell>
        <TableCell>{listPrice.price_cs_vietnam}</TableCell>
        <TableCell>{listPrice.price_cs_gmobile}</TableCell>
        <TableCell>{listPrice.price_cs_itelecom}</TableCell>
        <TableCell>{listPrice.price_cs_zalo}</TableCell>
      </TableRow>
    )
  }

  const _renderTablePrice = () => {
    const listTitleTable = [
      { code: 'sms_type', value: 'Loại tin nhắn' },
      { code: 'mobifone', value: 'Mobifone' },
      { code: 'vina', value: 'Vina' },
      { code: 'viettel', value: 'Viettel' },
      { code: 'vietnamobile', value: 'Vietnamobile' },
      { code: 'gmoblie', value: 'Gmobile' },
      { code: 'itelecom', value: 'Itelecom' },
      { code: 'zalo', value: 'Zalo' },
    ]
    return (
      <>
        {loading && <LinearProgress />}
        <Table sx={{ backgroundColor: '#fff' }}>
          <TableHead>
            <TableRow>
              {listTitleTable.map((item, index) => {
                return (<TableCell key={index} sx={{ color: 'black', fontWeight: "bold" }}>{item.value}</TableCell>)
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {listPrice && _renderPriceAds()}
            {listPrice && _renderPriceCs()}
          </TableBody>
        </Table>
      </>
    )
  }

  const _renderPriceInfo = () => {
    return (
      <Box sx={{
        margin: '10px 10px',
        backgroundColor: '#fff',
        borderRadius: '5px',
        padding: '10px'
      }}>
        <Box component='div' sx={{
          display: 'flex',
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: 'center'
        }}>
          <Box component='h3' sx={{ margin: "0px" }}>Bảng giá áp dụng</Box>
          <Button onClick={() => setModalUpdatePriceVisible(true)}>Chỉnh sửa giá</Button>
        </Box>
        {_renderTablePrice()}
      </Box>
    )
  }

  const _renderHeader = () => {
    return (
      <Box
        component='div'
        sx={{
          display: 'flex',
          flexDirection: 'row',
          marginLeft: '10px',
          marginTop: '10px',
          cursor: 'pointer'
        }}
        onClick={handleGoback}>
        <ArrowBackIosNewIcon />
        <Box component='h3' sx={{ marginTop: '0px' }}>Danh sách công ty</Box>
      </Box>
    )
  }

  const _renderCompanyInfo = () => {
    return (
      <>
        {_renderCompanyDetail()}
        {_renderPriceInfo()}
        <TransactionHistorty refCompanyId={companyInfo.ref_company_id} />
        <ModalRecharge
          open={modalRechargeVisible}
          handleCloseModalRecharge={handleCloseModalRecharge}
          walletId={walletId}
          getWalletOfUser={handleGetWallet}
          notiErr={notiErr}
        />
        {listPrice && (
          <ModalUpdatePrice
            open={modalUpdatePriceVisible}
            handleCloseModalUpdatePrice={handleCloseModalUpdatePrice}
            listPrice={listPrice}
            refCompanyId={companyInfo.ref_company_id}
            getSmsPriceList={handleGetListPrice}
            notiErr={notiErr}
          />
        )}
      </>
    );
  };

  const _tabProps = (index: number) => {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tab-${index}`
    };
  };

  const _renderTabs = () => {
    return (
      <Box component="div" sx={{ margin: '10px' }}>
        <Tabs
          value={tabValue}
          onChange={(e: any, value: number) => setTabValue(value)}
          aria-label="basic tabs example"
          sx={{ marginBottom: '10px' }}
        >
          <Tab label="Thông tin công ty" {..._tabProps} />
          <Tab label="Quản lý template" {..._tabProps} />
        </Tabs>
        <TabPanel value={tabValue} index={0}>
          {_renderCompanyInfo()}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <SmsTemplate refCompanyId={companyInfo.ref_company_id} listBrandname={listBrandname} />
        </TabPanel>
      </Box>
    );
  };

  return (
    <Box component="div">
      {_renderHeader()}
      {_renderTabs()}
      <Snackbar
        open={notification.isNoti}
        autoHideDuration={3000}
        onClose={closeNotifi}
        anchorOrigin={{ horizontal: 'right', vertical: 'top' }}
      >
        <Alert
          onClose={closeNotifi}
          severity={notification.notiType}
          sx={{ width: '100%', marginTop: '70px' }}
        >
          {notification.notiTitle}
        </Alert>
      </Snackbar>
    </Box>
  );
}
