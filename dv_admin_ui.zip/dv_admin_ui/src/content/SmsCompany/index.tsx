import { Button, FormControl, InputLabel, LinearProgress, MenuItem, Select, Table, TableBody, TableCell, TableHead, TablePagination, TableRow, TextField } from '@mui/material'
import { Box } from '@mui/system'
import moment from 'moment'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import api from 'src/api'
import { COMPANY_TYPE, LIST_COMPANY_TYPE, TABLE_PAGE } from 'src/constants'
import { SmsCompany, SmsCompanySearch } from 'src/models/smsCompany'
import { FormatDate } from 'src/utils/date'

export default function CompanySms() {
  const navigate = useNavigate()
  const [companyName, setComapnyName] = useState('')
  const [phoneNo, setPhoneNo] = useState('')
  const [companyType, setCompanyType] = useState('')
  const [page, setPage] = useState(TABLE_PAGE.PAGE)
  const [size, setSize] = useState(TABLE_PAGE.SIZE)
  const [totalElements, setTotalElement] = useState()
  const [listCompanySMS, setListCompanySms] = useState<SmsCompany[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getAllSmsCompany()
  }, [page, size])

  const getAllSmsCompany = async () => {
    setLoading(true)
    try {
      const data: SmsCompanySearch = {
        company_name: companyName,
        company_type: companyType,
        phone_no: phoneNo,
      }
      const res = await api.smsCompany.getAllSmsCompany(data, page + 1, size)
      setListCompanySms(res.data.data)
      setTotalElement(res.data.total_elements)
      setLoading(false)
    }
    catch (error) {
      setLoading(false)
    }
  }

  const handleChangeCompanyType = (e: any) => {
    setCompanyType(e.target.value)
  }

  const handleChangePage = (event: any, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: any) => {
    setSize(+event.target.value);
    setPage(0);
  }

  const handleDetailCompany = (item: SmsCompany) => {
    navigate(`/management/sms-company/${item.company_id}`, {
      state: item
    });
  }

  const handleSearch = () => {
    getAllSmsCompany()
  }

  const _renderTableHeadCompany = () => {
    const columnsCompany = [
      { code: 'company_name', label: 'Tên công ty' },
      { code: 'company_type', label: 'Loại công ty' },
      { code: 'phone_no', label: 'Số điện thoại' },
      { code: 'email', label: 'Email' },
      { code: 'created_date', label: 'Ngày tạo' },
    ]
    return (
      <TableRow className='table-title'>
        {columnsCompany.map((column) => (
          <TableCell
            key={column.code}
            className='row-name'
            sx={{ color: '#fff', backgroundImage: 'linear-gradient(90deg, #141e30 0%, #243b55 100%)' }}>
            {column.label}
          </TableCell>
        ))}
      </TableRow>
    )
  }

  const _renderTableBodyCompany = (item: SmsCompany, index: number) => {
    const companyType = LIST_COMPANY_TYPE.find((itemCompany, index) => itemCompany.type_code === item.company_type)
    return (
      <TableRow key={index} onClick={() => handleDetailCompany(item)} hover sx={{ cursor: 'pointer' }}>
        <TableCell>{item.company_name}</TableCell>
        <TableCell>{companyType && companyType.type_name}</TableCell>
        <TableCell>{item.phone_no}</TableCell>
        <TableCell>{item.email}</TableCell>
        <TableCell>{FormatDate(item.created_date)}</TableCell>
      </TableRow>
    )
  }

  const _renderTableSmsCompany = () => {
    return (
      <Table aria-label="purchases" sx={{ margin: 1 }}>
        <TableHead>
          {_renderTableHeadCompany()}
        </TableHead>
        <TableBody>
          {loading && <LinearProgress />}
          {listCompanySMS.map((item: SmsCompany, index: number) => _renderTableBodyCompany(item, index))}
        </TableBody>
      </Table>
    )
  }

  const _renderItemSearch = (lable: string, onChange: any, value: string) => {
    return (
      <FormControl sx={{ m: 1 }} >
        <TextField
          sx={{ width: 300 }}
          label={lable}
          variant="outlined"
          value={value}
          onChange={onChange}
        />
      </FormControl>
    )
  }

  const _renderSearch = () => {
    return (
      <Box px={3} display={'flex'} flexDirection={'row'} justifyContent="space-between">
        {_renderItemSearch("Tên công ty", (e: any) => setComapnyName(e.target.value), companyName)}
        {_renderItemSearch("Số điện thoại", (e: any) => setPhoneNo(e.target.value), phoneNo)}
        <FormControl sx={{ m: 1 }}>
          <InputLabel>Loại công ty</InputLabel>
          <Select
            sx={{ width: 300 }}
            value={companyType}
            onChange={handleChangeCompanyType}
            label="Loại công ty"
          >
            {COMPANY_TYPE.map((item, index) => {
              return (
                <MenuItem key={index} value={item.value}>{item.name}</MenuItem>
              )
            })}
          </Select>
        </FormControl>
      </Box>
    )
  }
  return (
    <Box component='div'>
      <Box component='h3' sx={{ textAlign: "center" }}>Quản lý công ty đăng kí dịch vụ SMS </Box>
      {_renderSearch()}
      <Button onClick={handleSearch} sx={{ float: 'right', margin: '0px 20px' }}>Tìm kiếm</Button>
      {_renderTableSmsCompany()}
      <TablePagination
        rowsPerPageOptions={[10, 20, 50, 100]}
        component="div"
        count={totalElements}
        rowsPerPage={size}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Box>
  )
}
