import { Alert, AlertColor, Button, LinearProgress, Snackbar, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material"
import { Box } from "@mui/system"
import { useEffect, useState } from "react"
import api from "src/api"
import { SmsBrandname, SmsTemplateResponse } from "src/models/smsCompany"
import DeleteIcon from '@mui/icons-material/Delete';
import AlertDialog from "src/components/DialogConfirm"
import { LIST_TYPE_STATUS_TEMPLATE } from "src/constants"
import ModalCreateTemplate from "./ModalCreateTemplate"
type Props = {
  refCompanyId: number,
  listBrandname: SmsBrandname[]
}

export type Notification = {
  isNoti: boolean
  notiType: AlertColor,
  notiTitle: string,
}

const initNoti: Notification = {
  isNoti: false,
  notiType: 'success',
  notiTitle: '',
}

export default function SmsTemplate(props: Props) {
  const { refCompanyId, listBrandname } = props
  const [listSmsTemplate, setListSmsTemplate] = useState<SmsTemplateResponse[]>([])
  const [dialogDeleteTemplateVisible, setDialogDeleteTemplateVisible] = useState(false)
  const [templateIdActive, setTemplateIdActive] = useState(0)
  const [notification, setNotification] = useState<Notification>(initNoti)
  const [loading, setLoading] = useState(false)
  const [modalCreateTemplate, setModalCreateTemplate] = useState(false)

  useEffect(() => {
    getListSmsTemplate()
  }, [])

  const getListSmsTemplate = async () => {
    setLoading(true)
    try {
      const res = await api.smsCompany.getListSmsTemplate(refCompanyId)
      setListSmsTemplate(res.data)
      setLoading(false)
    }
    catch (err) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Không thể lấy danh sách template!'
      })
      setLoading(false)
    }
  }

  const deleteTemplate = async () => {
    try {
      await api.smsCompany.deleteSmsTemplate(templateIdActive)
      getListSmsTemplate()
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Xóa template thành công!'
      })
      setDialogDeleteTemplateVisible(false)
      getListSmsTemplate()
    }
    catch (err) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Xóa template không thành công!'
      })
      setDialogDeleteTemplateVisible(false)
    }
  }

  const handleCreateTemplate = async (values: any) => {
    try {
      const res = await api.smsTemplate.createSmsTemplate(values);
      console.log(res.data);
      if (res.data?.status_code === 200) {
        setNotification({
          isNoti: true,
          notiType: 'success',
          notiTitle: 'Tạo template thành công!'
        });
      }
      getListSmsTemplate()
    } catch (error) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Thất bại do template này đã tồn tại'
      });
    } finally {
      setModalCreateTemplate(false);
    }
  };


  const closeNotifi = () => {
    setNotification(initNoti)
  }

  const handleCloseDiaLog = () => {
    setDialogDeleteTemplateVisible(false)
  }

  const handleRemove = (item: SmsTemplateResponse) => {
    setDialogDeleteTemplateVisible(true)
    setTemplateIdActive(item.template_id)
  }

  const handleCloseModalCreateTemplate = () => {
    setModalCreateTemplate(false);
  }

  const _renderRowSms = (item: SmsTemplateResponse, index: number) => {
    const status = LIST_TYPE_STATUS_TEMPLATE.find((type) => type.code === item.status)
    return (
      <TableRow key={index}>
        <TableCell>{item.template_id}</TableCell>
        <TableCell>{item.template_name}</TableCell>
        <TableCell>{item.template_content}</TableCell>
        <TableCell>{item.channel_code}</TableCell>
        <TableCell>{status && status.name}</TableCell>
        <TableCell>
          <Button sx={{ cursor: 'pointer' }}>
            <DeleteIcon onClick={() => handleRemove(item)} />
          </Button>
        </TableCell>
      </TableRow>
    )
  }

  const _renderTableSmsTemplate = () => {
    const column = [
      { code: "template_id", name: 'Mã template' },
      { code: "template_name", name: 'Tên template' },
      { code: "template_content", name: 'Nội dung' },
      { code: "channel_code", name: 'Kênh gửi' },
      { code: "status", name: 'Trạng thái' },
      { code: "remove", name: 'Xóa' },
    ]
    return (
      <Table size="small">
        {loading && <LinearProgress />}
        <TableHead>
          <TableRow>
            {column.map((item, index: number) => {
              return (
                <TableCell key={index}
                  className='row-name'
                  sx={{ color: '#fff', backgroundImage: 'linear-gradient(90deg, #141e30 0%, #243b55 100%)' }}
                >{item.name}
                </TableCell>
              )
            })}
          </TableRow>
        </TableHead>
        <TableBody>
          {listSmsTemplate.map((item: SmsTemplateResponse, index: number) => _renderRowSms(item, index))}
        </TableBody>
      </Table>
    )
  }
  return (
    <Box component='div'>
      <Box component="div" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box component="h3">Danh sách template</Box>
        <Button
          color="primary"
          onClick={() => setModalCreateTemplate(true)}
        >
          Tạo template
        </Button>
      </Box>
      {_renderTableSmsTemplate()}
      <AlertDialog
        title='Xóa template'
        content={`Bạn có chắn xóa template này không?`}
        open={dialogDeleteTemplateVisible}
        close={handleCloseDiaLog}
        handleNo={handleCloseDiaLog}
        handleYes={() => deleteTemplate()}
      />
      <ModalCreateTemplate
        open={modalCreateTemplate}
        onClose={handleCloseModalCreateTemplate}
        handleNo={handleCloseModalCreateTemplate}
        handleYes={handleCreateTemplate}
        listBrandname={listBrandname}
      />
      <Snackbar open={notification.isNoti} autoHideDuration={3000} onClose={closeNotifi} anchorOrigin={{ horizontal: 'right', vertical: 'top' }}>
        <Alert onClose={closeNotifi} severity={notification.notiType} sx={{ width: '100%', marginTop: '70px' }}>
          {notification.notiTitle}
        </Alert>
      </Snackbar>
    </Box>
  )
}
