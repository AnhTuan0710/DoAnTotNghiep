import { DatePicker } from '@mui/lab'
import { Box, Button, FormControl, InputLabel, LinearProgress, MenuItem, Select, Table, TableBody, TableCell, TableHead, TablePagination, TableRow, TextField } from '@mui/material'
import moment from 'moment'
import { useEffect, useState } from 'react'
import api from 'src/api'
import { LIST_CASHFLOW_TYPE, TABLE_PAGE } from 'src/constants'
import { SmsCashflow } from 'src/models/smsCompany'
import { FormatDate, FormatFromTime, FormatToTime } from 'src/utils/date'
import { MoneyFormat } from 'src/utils/money'

type Props = {
  refCompanyId: number
}

export default function TransactionHistorty(props: Props) {
  const { refCompanyId } = props
  const [page, setPage] = useState(TABLE_PAGE.PAGE)
  const [size, setSize] = useState(TABLE_PAGE.SIZE)
  const [totalElements, setTotalElement] = useState(0)
  const [listTransaction, setListTransaction] = useState([])
  const [fromTime, setFromTime] = useState('')
  const [toTime, setTotime] = useState('')
  const [cashflowType, setCashflowType] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getTransactionHistory()
  }, [page, size])

  const handleChangePage = (event: any, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: any) => {
    setSize(+event.target.value)
    setPage(TABLE_PAGE.PAGE);
  }

  const getTransactionHistory = async () => {
    setLoading(true)
    try {
      const data: SmsCashflow = {
        from_time: fromTime ? FormatFromTime(fromTime) : '',
        to_time: toTime ? FormatToTime(toTime) : '',
        cashflow_type: cashflowType
      }
      const res = await api.smsCompany.getListCashFlowOfCompany(data, refCompanyId, page + 1, size)
      setListTransaction(res.data.data)
      setTotalElement(res.data.total_elements)
      setLoading(false)
    }
    catch (err) {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    getTransactionHistory()
  }

  const _renderTableBodyHistory = () => {
    return (
      <TableBody>
        {loading && <LinearProgress />}
        {listTransaction.map((item, index) => {
          const cashFlowType = LIST_CASHFLOW_TYPE.find((cashFlow, index) => cashFlow.cashflow_code === item.cashflow_type)
          return (
            <TableRow key={index}>
              <TableCell>{item.cashflow_code}</TableCell>
              <TableCell>{item.cashflow_name}</TableCell>
              <TableCell>{cashFlowType && cashFlowType.value}</TableCell>
              <TableCell>{MoneyFormat(item.amount)}</TableCell>
              <TableCell>{item.ref_code}</TableCell>
              <TableCell>{FormatDate(item.created_date)}</TableCell>
            </TableRow>
          )
        })}
      </TableBody>
    )
  }

  const _renderTableHeaderHistory = () => {
    const column = [
      { code: 'cashflow_code', name: 'Mã phiếu' },
      { code: 'cashflow_name', name: 'Tên phiếu' },
      { code: 'cashflow_type', name: 'Loại thu chi' },
      { code: 'amount', name: 'Số tiền' },
      { code: 'ref_code', name: 'Mã tham chiếu' },
      { code: 'created_date', name: 'Ngày tạo' },
    ]
    return (
      <TableHead>
        <TableRow>
          {column.map((item, index) => {
            return (
              <TableCell key={index} sx={{ color: 'black' }}>{item.name}</TableCell>
            )
          })}
        </TableRow>
      </TableHead>
    )
  }

  const _renderFormSearch = () => {
    return (
      <Box p={0} m={0} display={'flex'} flexDirection={'row'} justifyContent="space-between">
        <FormControl>
          <DatePicker
            value={fromTime}
            label='Thời gian từ'
            inputFormat={'dd/MM/yyyy'}
            onChange={(e: any) => { setFromTime(e) }}
            renderInput={(params) =>
              <TextField fullWidth {...params} variant='outlined' sx={{ m: 1 }} />}
          />
        </FormControl>
        <FormControl>
          <DatePicker
            value={toTime}
            label='Thời gian đến'
            inputFormat={'dd/MM/yyyy'}
            onChange={(e: any) => { setTotime(e) }}
            renderInput={(params) =>
              <TextField fullWidth {...params} variant='outlined' sx={{ m: 1 }} />}
          />
        </FormControl>
        <FormControl>
          <InputLabel>Loại thu chi</InputLabel>
          <Select
            sx={{ width: 300 }}
            value={cashflowType}
            onChange={(e: any) => setCashflowType(e.target.value)}
            label="Loại thu chi"
          >
            {LIST_CASHFLOW_TYPE.map((item, index) => {
              return (
                <MenuItem key={index} value={item.cashflow_code}>{item.value}</MenuItem>
              )
            })}
          </Select>
        </FormControl>
      </Box>
    )
  }
  return (
    <Box sx={{
      margin: '10px 10px',
      backgroundColor: '#fff',
      borderRadius: '5px',
      padding: '10px'
    }}>
      <Box component='h3' sx={{ margin: "0px" }}>Lịch sử giao dịch</Box>
      {_renderFormSearch()}
      <Button onClick={handleSearch} sx={{ float: 'right' }}>Tìm kiếm</Button>
      <Table>
        {_renderTableHeaderHistory()}
        {_renderTableBodyHistory()}
      </Table>
      <TablePagination
        rowsPerPageOptions={[10, 20, 50, 100]}
        component="div"
        count={totalElements}
        rowsPerPage={size}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Box>
  )
}

