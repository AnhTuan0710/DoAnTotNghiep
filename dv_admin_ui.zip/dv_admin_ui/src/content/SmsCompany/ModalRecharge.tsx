import { Button, FormControl, Input, InputLabel, Modal } from '@mui/material'
import { Box } from '@mui/system'
import { useState } from 'react';
import api from 'src/api';
import { RechargeWalletRequest } from 'src/models/wallet';
import { MoneyFormat, MoneyFormatToNumber } from 'src/utils/money';

type Props = {
  open: boolean,
  handleCloseModalRecharge: () => void,
  walletId: number,
  getWalletOfUser: () => void,
  notiErr: () => void
}

export default function ModalRecharge(props: Props) {
  const { open, handleCloseModalRecharge, walletId, getWalletOfUser, notiErr } = props
  const [price, setPrice] = useState(0)

  const handleSubmit = async () => {
    try {
      const data: RechargeWalletRequest = {
        wallet_id: walletId,
        amount: price
      }
      await api.wallet.rechargeWallet(data)
      handleCloseModalRecharge()
      getWalletOfUser()
    }
    catch (err) {
      handleCloseModalRecharge()
      notiErr()
    }
  }

  const _renderFooter = () => {
    return (
      <Box component='div' sx={{ borderTop: '1px solid gray' }}>
        <Button
          sx={{
            float: 'right',
            padding: '5px 10px',
            margin: '5px',
            borderRadius: '5px'
          }}
          onClick={handleSubmit}
          disabled={price === 0 ? true : false}
        >
          Xác nhận
        </Button>
      </Box>
    )
  }

  return (
    <Modal
      open={open}
      onClose={handleCloseModalRecharge}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={{
        position: 'absolute' as 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        bgcolor: 'background.paper',
        borderRadius: '5px',
        boxShadow: 24,
      }}>
        <Box component='h4'
          sx={{
            width: '100%',
            backgroundImage: "linear-gradient(90deg, #141e30 0%, #243b55 100%)",
            color: '#fff',
            m: 0,
            p: 1
          }}>
          Nạp tiền vào tài khoản
        </Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          <FormControl sx={{ mx: 1 }} variant="outlined">
            <InputLabel>Nhập số tiền</InputLabel>
            <Input
              value={MoneyFormat(price)}
              onChange={(e: any) => setPrice(MoneyFormatToNumber(e.target.value))}
            />
          </FormControl>
        </Box>
        {_renderFooter()}
      </Box>
    </Modal >
  )
}
