import { Button, FormControl, Input, InputLabel, Modal } from '@mui/material'
import { Box } from '@mui/system'
import { useState } from 'react';
import api from 'src/api';
import { SmsPriceList, SmsPriceListRequest } from 'src/models/smsCompany';
import { MoneyFormat, MoneyFormatToNumber } from 'src/utils/money';

type Props = {
  open: boolean,
  handleCloseModalUpdatePrice: () => void
  listPrice: SmsPriceList
  refCompanyId: number
  getSmsPriceList: () => void,
  notiErr: () => void,
}

export default function ModalUpdatePrice(props: Props) {
  const { open, handleCloseModalUpdatePrice, listPrice, refCompanyId, getSmsPriceList, notiErr } = props
  const [priceAdsMobi, setPriceAdsMobi] = useState(listPrice.price_ads_mobi)
  const [priceAdsVina, setPriceAdsVina] = useState(listPrice.price_ads_vina)
  const [priceAdsViettel, setPriceAdsViettel] = useState(listPrice.price_ads_viettel)
  const [priceAdsVietnam, setPriceAdsVietnam] = useState(listPrice.price_ads_vietnam)
  const [priceAdsGmobile, setPriceAdsGmobile] = useState(listPrice.price_ads_gmobile)
  const [priceCsMobi, setPriceCsMobi] = useState(listPrice.price_cs_mobi)
  const [priceCsVina, setPriceCsVina] = useState(listPrice.price_cs_vina)
  const [priceCsViettel, setPriceCsViettel] = useState(listPrice.price_cs_viettel)
  const [priceCsVietnam, setPriceCsVietnam] = useState(listPrice.price_cs_vietnam)
  const [priceCsGmobile, setPriceCsGmobile] = useState(listPrice.price_cs_gmobile)
  const [priceCsItelecom, setPriceCsItelecom] = useState(listPrice.price_cs_itelecom)
  const [priceZalo, setPriceZalo] = useState(listPrice.price_cs_zalo)

  const handleSummit = async () => {
    try {
      const data: SmsPriceListRequest = {
        ref_company_id: refCompanyId,
        price_ads_mobi: priceAdsMobi,
        price_ads_vina: priceAdsVina,
        price_ads_viettel: priceAdsViettel,
        price_ads_vietnam: priceAdsVietnam,
        price_ads_gmobile: priceAdsGmobile,
        price_cs_mobi: priceCsMobi,
        price_cs_vina: priceCsVina,
        price_cs_viettel: priceCsViettel,
        price_cs_vietnam: priceCsVietnam,
        price_cs_gmobile: priceCsGmobile,
        price_cs_itelecom: priceCsItelecom,
        price_cs_zalo: priceZalo,
      }
      await api.smsCompany.updateListPrice(data)
      handleCloseModalUpdatePrice()
      getSmsPriceList()
    }
    catch (err) {
      handleCloseModalUpdatePrice()
      notiErr()
    }
  }

  const _renderInput = (lable: string, onChange: any, value: number) => {
    return (
      <FormControl sx={{ mx: 1 }} variant="outlined">
        <InputLabel>{lable}</InputLabel>
        <Input
          value={MoneyFormat(value)}
          onChange={onChange}
        />
      </FormControl>
    )
  }

  const _renderPriceAds = () => {
    return (
      <>
        <Box component='p' sx={{ color: "black", px: 2, fontWeight: '600' }}> * Giá tin nhắn brandname quảng cáo (VNĐ/SMS)</Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          {_renderInput('Mobifone', (e) => setPriceAdsMobi(MoneyFormatToNumber(e.target.value)), priceAdsMobi)}
          {_renderInput('Vina', (e) => setPriceAdsVina(MoneyFormatToNumber(e.target.value)), priceAdsVina)}
          {_renderInput('Viettel', (e) => setPriceAdsViettel(MoneyFormatToNumber(e.target.value)), priceAdsViettel)}
        </Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          {_renderInput('Vietnam', (e) => setPriceAdsVietnam(MoneyFormatToNumber(e.target.value)), priceAdsVietnam)}
          {_renderInput('Gmobile', (e) => setPriceAdsGmobile(MoneyFormatToNumber(e.target.value)), priceAdsGmobile)}
        </Box>
      </>
    )
  }

  const _renderPriceCs = () => {
    return (
      <>
        <Box component='p' sx={{ color: "black", px: 2, fontWeight: '600' }}> * Giá tin nhắn brandname CSKH (VNĐ/SMS)</Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          {_renderInput('Mobifone', (e) => setPriceCsMobi(Number(e.target.value)), priceCsMobi)}
          {_renderInput('Vina', (e) => setPriceCsVina(Number(e.target.value)), priceCsVina)}
          {_renderInput('Viettel', (e) => setPriceCsViettel(Number(e.target.value)), priceCsViettel)}
        </Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          {_renderInput('Vietnam', (e) => setPriceCsVietnam(Number(e.target.value)), priceCsVietnam)}
          {_renderInput('Gmobile', (e) => setPriceCsGmobile(Number(e.target.value)), priceCsGmobile)}
          {_renderInput('Itelecom', (e) => setPriceCsItelecom(Number(e.target.value)), priceCsItelecom)}
        </Box>
      </>
    )
  }

  const _renderFooter = () => {
    return (
      <Box component='div' sx={{ borderTop: '1px solid gray' }}>
        <Button sx={{
          float: 'right',
          backgroundImage: "linear-gradient(90deg, #141e30 0%, #243b55 100%)",
          color: '#fff',
          padding: '5px 10px',
          margin: "5px",
          borderRadius: '5px'
        }}
          onClick={handleSummit}
        >
          Xác nhận
        </Button>
      </Box>
    )
  }

  const _renderPriceZalo = () => {
    return (
      <>
        <Box component='p' sx={{ color: "black", px: 2, fontWeight: '600' }}> * Giá tin nhắn zalo (VNĐ/SMS)</Box>
        <Box component='div' sx={{ display: 'flex', alignItem: 'center', m: 2 }}>
          {_renderInput('Zalo', (e) => setPriceZalo(e.target.value), priceZalo)}
        </Box>
      </>
    )
  }

  return (
    <Modal
      open={open}
      onClose={handleCloseModalUpdatePrice}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={{
        position: 'absolute' as 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        bgcolor: 'background.paper',
        borderRadius: '5px',
        boxShadow: 24,
      }}>
        <Box component='h4'
          sx={{
            width: '100%',
            backgroundImage: "linear-gradient(90deg, #141e30 0%, #243b55 100%)",
            color: '#fff',
            m: 0, p: 1
          }}>
          Cập nhật giá các gói dịch vụ
        </Box>
        {_renderPriceAds()}
        {_renderPriceCs()}
        {_renderPriceZalo()}
        {_renderFooter()}
      </Box>
    </Modal >
  )
}
