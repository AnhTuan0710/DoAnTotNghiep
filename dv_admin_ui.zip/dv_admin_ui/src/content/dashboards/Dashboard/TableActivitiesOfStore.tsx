import { Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material'
import { LIST_ACTIVITY_TYPE } from 'src/constants'
import { DrgActivity } from 'src/models/activtity'
import { FormatTimeActice } from 'src/utils/date'

type Props = {
  activities: DrgActivity[]
  loading: boolean
}

type Column = {
  label: string
  align: string,
  width: number
}

const TableActivitiesOfStore = (props: Props) => {
  const { activities, loading } = props

  const columns = [
    { label: 'Activity Type', align: 'left', width: 80 },
    { label: 'Content', align: 'left', width: 160 },
    { label: 'Time', align: 'left', width: 80 }
  ]

  const _renderHeadRowCell = (item: Column, index: number) => {
    <TableCell
      key={index}
      sx={{ backgroundImage: 'linear-gradient(90deg, #cfd9df 0%, #e2ebf0 100%)', width: item.width }}>
      {item.label}
    </TableCell>
  }

  const _renderBodyRow = (activity: DrgActivity) => {
    const content = JSON.parse(activity.content_activity)
    const activityContent = Object.entries(content).map(([key, val]) => {
      return key + ': ' + val + ', '
    })
    const activetyType = LIST_ACTIVITY_TYPE.find((item) => item.value === activity.activity_type)?.name
    return (
      <TableRow key={activity.activity_id}>
        <TableCell component="th" scope="row" sx={{ width: 80 }}>
          {activetyType}
        </TableCell>
        <TableCell sx={{ width: 160 }}>{activityContent}</TableCell>
        <TableCell sx={{ width: 80 }} align="left">{FormatTimeActice(activity.created_date)}</TableCell>
      </TableRow>
    )
  }

  return (
    <Table size="small" aria-label="purchases" sx={{ marginLeft: 6 }}>
      <TableHead>
        <TableRow>
          {columns.map((item, index) => _renderHeadRowCell(item, index))}
        </TableRow>
      </TableHead>
      {!loading && <TableBody>
        {activities.map((activity: DrgActivity) => _renderBodyRow(activity))}
      </TableBody>}
    </Table>
  )
}

export default TableActivitiesOfStore