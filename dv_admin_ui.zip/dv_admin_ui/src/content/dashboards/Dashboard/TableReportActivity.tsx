
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { Box, Collapse, FormControl, IconButton, InputLabel, LinearProgress, MenuItem, Select, Tab, Tabs, TextField, Typography } from '@mui/material';
import React, { SyntheticEvent, useEffect, useState } from 'react';
import { CONTRACT_TYPE, LIST_ACTIVITY_TYPE, LIST_CONTRACT_TYPE, TABLE_PAGE } from 'src/constants';
import { DrgActivity, ReportActivityResponse } from 'src/models/activtity';
import API from '../../../api'
import { a11yProps } from '../../../utils/animation'
import { FirstdayOfMonth, FirstdayOfYear, FormatDayOfWeekAgo, FormatFromTime, FormatToTime } from 'src/utils/date';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import TableActivitiesOfStore from './TableActivitiesOfStore';
import useDebounce from 'src/app/debounce';
import { DatePicker } from '@mui/lab';

interface Column {
  id: string
  label: string
  minWidth: number
}

const columns: Column[] = [
  { id: 'stt', label: 'STT', minWidth: 10 },
  { id: 'drg_store_code', label: 'Store code', minWidth: 80 },
  { id: 'drg_store_name', label: 'Store name', minWidth: 160 },
  { id: 'city', label: 'Address', minWidth: 160 },
  { id: 'phone_no', label: 'Phone number', minWidth: 80 },
  { id: 'total_activity', label: 'Total activities', minWidth: 80 },
];

export default function TableReportActivity() {
  const today = new Date().toString()
  const [contractType, setContractType] = useState('')
  const [activityType, setActivityType] = useState('')
  const [storeName, setStoreName] = useState('')
  const [date, setDate] = useState('Today')
  const [page, setPage] = useState(TABLE_PAGE.PAGE);
  const [size, setSize] = useState(TABLE_PAGE.SIZE);
  const [stores, setStores] = useState<ReportActivityResponse[]>([])
  const [storeId, setStoreId] = useState<number | null>(null)
  const [totalElements, setTotalElements] = useState(0)
  const [activity, setActivity] = useState<DrgActivity[]>([])
  const [loading, setLoading] = useState(false)
  const [loadingCollapse, setLoadingCollapse] = useState(false)
  const debounceStoreName = useDebounce(storeName, 700)
  const [fromTime, setFromTime] = useState(FormatFromTime(today))
  const [toTime, setToTime] = useState(FormatToTime(today))

  useEffect(() => {
    getReportActivity()
    getAllActivityOfStore()
  }, [debounceStoreName, contractType, activityType, fromTime, toTime, page, size])

  useEffect(() => {
    if (storeId) getAllActivityOfStore()
  }, [storeId])

  const getReportActivity = async () => {
    const params = {
      from_time: fromTime,
      to_time: toTime,
      drg_name: storeName,
      activity_type: activityType
    }
    try {
      setLoading(true)
      const res = await API.activity.reportActivityOfStore(params, page + 1, size)
      setStores(res.data.data)
      setTotalElements(res.data.total_elements)
    } catch (err) {
      setStores([])
      setTotalElements(0)
    } finally {
      setLoading(false)
    }
  }

  const getAllActivityOfStore = async () => {
    try {
      setLoadingCollapse(true)
      const res = await API.activity.getAllActivity(storeId, fromTime, toTime)
      setActivity(res.data)
    } catch (err) {
      setActivity([])
    } finally {
      setLoadingCollapse(false)
    }
  }

  const handleChangePage = (event, newPage) => {
    console.log('keytest', newPage);
    setPage(newPage)
  }
  const handleChangeRowsPerPage = (event) => {
    setSize(+event.target.value);
    setPage(0);
  };
  const handleChangeContractType = (e) => {
    setContractType(e.target.value)
  }
  const handleChangeActivityType = (e) => {
    setActivityType(e.target.value)
  }
  const handelChangeTime = (event: SyntheticEvent, newValue: string) => {
    setDate(newValue)
    setToTime(FormatToTime(today))
    switch (newValue) {
      case 'Today': {
        setFromTime(FormatFromTime(today))
        break;
      }
      case 'A week': {
        setFromTime(FormatDayOfWeekAgo(today))
        break;
      }
      case 'This month': {
        setFromTime(FirstdayOfMonth(today))
        break;
      }
      case 'This year': {
        setFromTime(FirstdayOfYear(today))
        break;
      }
    }
  }

  const _renderFilter = () => (
    <Box
      display={'flex'}
      justifyContent='space-between'
      flexDirection={'column'}
      mb={1}
    >
      <Box px={3} display={'flex'} flexDirection={'row'} justifyContent="space-between">
        <FormControl sx={{ m: 1 }} >
          <TextField sx={{ width: 300 }} label="Store name" variant="outlined"
            value={storeName}
            onChange={(e: any) => { setStoreName(e.target.value) }}
          />
        </FormControl>
        <FormControl sx={{ m: 1 }}>
          <InputLabel>Contract type</InputLabel>
          <Select
            sx={{ width: 300 }}
            value={contractType}
            onChange={handleChangeContractType}
            label="Contract type"
            defaultValue={CONTRACT_TYPE.BASIC}
          >
            {LIST_CONTRACT_TYPE.map((item, index) =>
              <MenuItem value={item.value} key={index}>{item.name}</MenuItem>
            )}
          </Select>
        </FormControl>
        <FormControl sx={{ m: 1 }}>
          <InputLabel>Activity type</InputLabel>
          <Select
            sx={{ width: 408 }}
            value={activityType}
            onChange={handleChangeActivityType}
            label="Activity type"
            defaultValue={CONTRACT_TYPE.BASIC}
          >
            {LIST_ACTIVITY_TYPE.map((item, index) =>
              <MenuItem value={item.value} key={index}>{item.name}</MenuItem>
            )}
          </Select>
        </FormControl>
      </Box>
      <Box px={3} display={'flex'} flexDirection={'row'} justifyContent="space-between" alignItems={'center'}>
        <FormControl sx={{ ml: 1 }}>
          <DatePicker
            value={fromTime}
            label='Từ ngày'
            inputFormat={'dd/MM/yyyy'}
            onChange={(e: any) => { setFromTime(FormatFromTime(e)) }}
            renderInput={(params) =>
              <TextField fullWidth {...params} variant='outlined' sx={{ width: 300 }} />}
          />
        </FormControl>
        <FormControl>
          <DatePicker
            value={toTime}
            label='Đến ngày'
            inputFormat={'dd/MM/yyyy'}
            onChange={(e: any) => { setToTime(FormatToTime(e)) }}
            renderInput={(params) =>
              <TextField fullWidth {...params} variant='outlined' sx={{ width: 300 }} />}
          />
        </FormControl>
        <Tabs
          sx={{ mx: 1 }}
          variant="scrollable"
          scrollButtons="auto"
          textColor="primary"
          indicatorColor="primary"
          value={date}
          onChange={handelChangeTime}
        >
          <Tab label="Today" value="Today" {...a11yProps(0)} />
          <Tab label="A week" value="A week" {...a11yProps(1)} />
          <Tab label="This month" value="This month" {...a11yProps(2)} />
          <Tab label="This year" value="This year" {...a11yProps(3)} />
        </Tabs>
      </Box>
    </Box>
  )

  const _renderTableHead = () => (
    <TableRow>
      <TableCell sx={{ backgroundImage: 'linear-gradient(90deg, #141e30 0%, #243b55 100%)', width: 70 }} />
      {columns.map((column) =>
        <TableCell key={column.id}
          sx={{ backgroundImage: 'linear-gradient(90deg, #141e30 0%, #243b55 100%)', fontWeight: 'bolder', color: '#fff', minWidth: column.minWidth }}
        >
          {column.label}
        </TableCell>)}
    </TableRow>
  )

  const _renderItemStore = (item: ReportActivityResponse, index: number) => (
    <React.Fragment key={item.drg_store_id}>

      <TableRow hover>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={(e) => {
              e.stopPropagation()
              setStoreId((prevState: number) => storeId && prevState === item.drg_store_id ? null : item.drg_store_id)
            }}
          >
            {storeId === item.drg_store_id ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell>{index + 1}</TableCell>
        <TableCell>{item.drg_store_code}</TableCell>
        <TableCell>{item.drg_name}</TableCell>
        <TableCell>{`${item.address1} - ${item.district} - ${item.city}`}</TableCell>
        <TableCell>{item.phone_no}</TableCell>
        <TableCell sx={{ textAlign: 'center' }}>{item.total_activity}</TableCell>
      </TableRow>

      <TableRow>
        <TableCell sx={{ paddingTop: 0, paddingBottom: 0 }} colSpan={6}>
          <Collapse in={storeId === item.drg_store_id ? true : false} timeout="auto" unmountOnExit>
            {loadingCollapse && storeId === item.drg_store_id && <LinearProgress />}
            <TableActivitiesOfStore activities={activity} loading={loadingCollapse} />
          </Collapse>
        </TableCell>
      </TableRow>

    </React.Fragment>
  )

  const _renderTable = () => (
    <TableContainer>
      {loading && <LinearProgress />}
      <Table stickyHeader aria-label="sticky table">

        <TableHead>
          {_renderTableHead()}
        </TableHead>

        <TableBody>
          {stores.map((item, index) => _renderItemStore(item, index))}
        </TableBody>

      </Table>
    </TableContainer>
  )

  const _renderTablePagination = () => (
    <TablePagination
      rowsPerPageOptions={[10, 20, 50, 100]}
      component="div"
      count={totalElements}
      rowsPerPage={size}
      page={page}
      onPageChange={handleChangePage}
      onRowsPerPageChange={handleChangeRowsPerPage}
    />
  )

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <Typography pt={1} variant="h3" textAlign='center'>Store Activity</Typography>
      {_renderFilter()}
      {_renderTable()}
      {_renderTablePagination()}
    </Paper>
  );
}
