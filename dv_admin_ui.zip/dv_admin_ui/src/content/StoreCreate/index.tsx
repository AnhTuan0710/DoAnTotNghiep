import { Alert, AlertColor, Button, FormControl, FormHelperText, InputLabel, MenuItem, Select, Snackbar, TextField } from '@mui/material'
import { Box } from '@mui/system'
import { useState } from 'react';
import { COMPANY_TYPE } from 'src/constants';
import AddIcon from '@mui/icons-material/Add';
import { DataCounty } from 'src/models/dataCountry';
import { CreateStoreType } from 'src/models/account';
import api from 'src/api';
import { LoadingButton } from '@mui/lab';
import { useNavigate } from 'react-router';

const dataCountry: DataCounty = require('../../assets/data/dataCountry.json')
const listDataCity = dataCountry.data
const listCompanyType = COMPANY_TYPE.filter((item) => item.code !== 'ALL' && item.code !== 'PHARMACIST')
const regexPhone = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
const regexEmail = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

type MessageError = {
  errStoreName: string,
  errCity: string,
  errCompanyType: string,
  errCompanyName: string,
  errDistrict: string,
  errPhone: string,
  errEmail: string,
  errPassword: string,
  errSource: string,
}
const initMessageError: MessageError = {
  errStoreName: '',
  errCity: '',
  errCompanyType: '',
  errCompanyName: '',
  errDistrict: '',
  errPhone: '',
  errEmail: '',
  errPassword: '',
  errSource: ''
}
type Notification = {
  isNoti: boolean,
  notiType: AlertColor,
  notiTitle: string,
}
const initNoti: Notification = {
  isNoti: false,
  notiType: 'success',
  notiTitle: '',
}

type CompanyType = {
  value: string,
  name: string,
}
type ListCompanyType = CompanyType[]

export default function CreateStore() {
  const navigate = useNavigate()
  const [companyType, setCompanyType] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [city, setCity] = useState('')
  const [district, setDistrict] = useState('')
  const [storeName, setStoreName] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [source, setSource] = useState('')
  const [listDataDistrict, setListDistrict] = useState([])
  const [messageError, setMessageError] = useState<MessageError>(initMessageError)
  const [notification, setNotification] = useState<Notification>(initNoti)
  const [isLoading, setIsLoading] = useState(false)

  const createAccount = async () => {
    setIsLoading(true)
    try {
      const data: CreateStoreType = {
        store_name: storeName,
        phone_no: phone,
        password: password,
        email: email,
        city: city,
        district: district,
        company_name: companyName,
        company_type: companyType,
        address: '',
        source: source,
      }
      await api.account.createAccount(data)
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Thêm cửa hàng thành công'
      })
      setIsLoading(false)
      setStoreName('')
      setPhone('')
      setEmail('')
      setCompanyName('')
      setPassword('')
      setCompanyType('')
      setCity('')
      setDistrict('')
      setSource('')
    }
    catch (error) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Thêm cửa hàng thất bại'
      })
      setIsLoading(false)
      console.log(error);

      if (error.response.data.message === "Phone number is exist, please input other number ") {
        setMessageError({ ...messageError, errPhone: "Số đã được đăng kí" })
      }
    }
  }

  const handleAdd = () => {
    let isError = false
    const errNew = JSON.parse(JSON.stringify(messageError))
    if (storeName === '') {
      errNew.errStoreName = 'Nhập tên cửa hàng'
      isError = true
    } else {
      errNew.errStoreName = ''
    }
    if (city === '') {
      errNew.errCity = 'Nhập tỉnh/thành phố'
      isError = true
    } else {
      errNew.errCity = ''
    }
    if (district === '') {
      errNew.errDistrict = 'Nhập quận/huyện'
      isError = true
    } else {
      errNew.errDistrict = ''
    }
    if (companyName === '') {
      errNew.errCompanyName = 'Nhập tên công ty'
      isError = true
    } else {
      errNew.errCompanyName = ''
    }
    if (companyType === '') {
      errNew.errCompanyType = 'Nhập loại công ty'
      isError = true
    } else {
      errNew.errCompanyType = ''
    }
    if (password === '') {
      errNew.errPassword = 'Nhập mật khẩu'
      isError = true
    } else if (password !== '' && password.length < 6) {
      errNew.errPassword = 'Mật khẩu phải hơn 6 kí tự'
      isError = true
    } else {
      errNew.errPassword = ''
    }
    if (source === '') {
      errNew.errSource = 'Nhập nguồn'
      isError = true
    } else {
      errNew.errSource = ''
    }
    if (email !== '' && regexEmail.test(email) === false) {
      errNew.errEmail = 'Email không hợp lệ'
      isError = true
    } else {
      errNew.errEmail = ''
    }
    if (phone === '') {
      errNew.errPhone = 'Nhập số điện thoại'
      isError = true
    } else if (phone !== '' && regexPhone.test(phone) === false) {
      errNew.errPhone = 'SĐT không hợp lệ'
      isError = true
    } else {
      errNew.errPhone = ''
    }
    setMessageError(errNew)
    if (isError === false) {
      createAccount()
    }
  }

  const onChangeCompanyType = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errCompanyType: "" })
    }
    setCompanyType(e)
  }

  const onChangeCompanyName = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errCompanyName: "" })
    }
    setCompanyName(e)
  }

  const onChangeCity = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errCity: "" })
    }
    setCity(e)
    setListDistrict(listDataCity.find((item) => item.name === e).level2s)
  }

  const onChangeDistrict = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errDistrict: "" })
    }
    setDistrict(e)
  }

  const onChangeStoreName = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errStoreName: "" })
    }
    setStoreName(e)
  }

  const onChangePhone = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errPhone: "" })
    }
    setPhone(e)
  }

  const onChangeEmail = (e: string) => {
    if (e === '' || regexEmail.test(e) === true) {
      setMessageError({ ...messageError, errEmail: "" })
    }
    setEmail(e)
  }

  const onChangePassword = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errPassword: "" })
    }
    setPassword(e)
  }

  const onChaneSource = (e: string) => {
    if (e !== '') {
      setMessageError({ ...messageError, errSource: "" })
    }
    setSource(e)
  }

  const _renderTextField = (value: string, label: string, type: string, message: string, onChange: React.ChangeEventHandler<HTMLInputElement | HTMLTextAreaElement>) => {
    return (
      <TextField
        error={message === '' ? false : true}
        value={value}
        label={label}
        type={type}
        variant="outlined"
        fullWidth
        helperText={message}
        sx={{ marginTop: '6px', height: '75px', marginRight: '5px' }}
        onChange={onChange}
      />
    )
  }

  const _renderSelectComapnyType = (label: string, listCompanyType: ListCompanyType, onChange: any, value: string, message: string) => {
    return (
      <FormControl variant="outlined" sx={{ marginTop: '6px', height: '75px', marginRight: '5px' }} fullWidth>
        <InputLabel id="demo-simple-select-standard-label">{label}</InputLabel>
        <Select
          value={value}
          onChange={onChange}
          error={message === '' ? false : true}
        >
          {listCompanyType.map((item: CompanyType) => {
            return (
              <MenuItem value={item.value} key={item.name}>{item.name}</MenuItem>
            )
          })}
        </Select>
        <FormHelperText sx={{ color: 'red' }}>{message}</FormHelperText>
      </FormControl>
    )
  }

  const _renderSelectAddress = (name: string, listOption: any, onChange: any, value: string, message: string) => {
    return (
      <FormControl variant="outlined" sx={{ marginTop: '6px', height: '75px', marginRight: '5px' }} fullWidth>
        <InputLabel id="demo-simple-select-standard-label">{name}</InputLabel>
        <Select
          value={value}
          onChange={onChange}
          error={message === '' ? false : true}
        >
          {listOption.map((item) => {
            return (
              <MenuItem value={item.name} key={item.name}>{item.name}</MenuItem>
            )
          })}
        </Select>
        <FormHelperText sx={{ color: 'red' }}>{message}</FormHelperText>
      </FormControl>
    )
  }

  const _renderButton = () => {
    return (
      <Box component='div' sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
        <Button onClick={() => navigate('/management/transactions')}>
          Quay lại
        </Button>
        <LoadingButton sx={{
          backgroundImage: 'linear-gradient(90deg, #2aa13c 0%, #11b72af4 100%)',
          color: '#fff', padding: ''
        }}
          onClick={handleAdd}
          loading={isLoading}
        >
          <AddIcon />
          Thêm
        </LoadingButton>
      </Box>
    )
  }

  const _renderContent = () => {
    const titleStoreName = companyType ? `Tên ` + listCompanyType.find((item) => item.value === companyType)?.name : 'Tên nhà thuốc'
    return (
      <Box component='div'
        sx={{
          alignItems: 'center', textAlign: 'center',
          borderRadius: '10px',
          width: '45%', margin: '10px auto',
        }}>
        {_renderSelectComapnyType('Loại công ty', listCompanyType, (e: any) => onChangeCompanyType(e.target.value), companyType, messageError.errCompanyType)}
        {_renderTextField(companyName, 'Tên công ty', 'text', messageError.errCompanyName, (e: any) => onChangeCompanyName(e.target.value))}
        <Box component='div' sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
          {_renderSelectAddress('Địa chỉ', listDataCity, (e: any) => onChangeCity(e.target.value), city, messageError.errCity)}
          {_renderSelectAddress('Quận/ huyện', listDataDistrict, (e: any) => onChangeDistrict(e.target.value), district, messageError.errDistrict)}
        </Box>
        {_renderTextField(storeName, titleStoreName, 'text', messageError.errStoreName, (e: any) => onChangeStoreName(e.target.value))}
        <Box component='div' sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
          {_renderTextField(phone, 'Số điện thoại', 'text', messageError.errPhone, (e: any) => onChangePhone(e.target.value))}
          {_renderTextField(email, 'Email', 'text', messageError.errEmail, (e: any) => onChangeEmail(e.target.value))}
        </Box>
        {_renderTextField(password, 'Mật khẩu', 'password', messageError.errPassword, (e: any) => onChangePassword(e.target.value))}
        {_renderTextField(source, 'Nguồn', 'source', messageError.errSource, (e: any) => onChaneSource(e.target.value))}
        {_renderButton()}
      </Box>
    )
  }

  return (
    <Box component='div'>
      <Box component='div' sx={{
        paddingTop: '10px', fontWeight: '600',
        fontSize: '23px', textAlign: "center",
      }}>
        Thêm cửa hàng
      </Box>
      {_renderContent()}
      <Snackbar open={notification.isNoti} autoHideDuration={4000} onClose={() => setNotification(initNoti)} anchorOrigin={{ horizontal: 'right', vertical: 'top' }}>
        <Alert onClose={() => setNotification(initNoti)} severity={notification.notiType} sx={{ width: '100%', marginTop: '70px' }}>
          {notification.notiTitle}
        </Alert>
      </Snackbar>
    </Box>
  )
}
