import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Alert, Button, CircularProgress, Collapse, FormControl, Input, MenuItem, Select, Snackbar, TablePagination } from '@mui/material';
import React, { ChangeEventHandler, Fragment, useEffect, useState } from 'react';
import api from 'src/api';
import moment from "moment";
import { Company, CompanySearch } from 'src/models/company';
import { COMPANY_TYPE, DATE_UTILS, LIST_COMPANY_TYPE, LIST_CONTRACT_TYPE, TABLE_PAGE } from 'src/constants';
import './storeManagement.scss'
import TableStore from './TableStore';

export default function StoreManagement() {
  const [companyType, setCompanyType] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [contractType, setContracType] = useState('')
  const [phoneNo, setPhoneNo] = useState('')
  const [page, setPage] = useState(TABLE_PAGE.PAGE)
  const [size, setSize] = useState(TABLE_PAGE.SIZE)
  const [totalElement, setTotalElement] = useState(0)
  const [listCompany, setListCompany] = useState<Company[]>([])
  const [idCompanyActive, setIdCompanyActive] = useState(0)
  const [isLoadingComapny, setIsLoadingComapny] = useState(false)
  const [notiError, setNotiError] = useState(false)

  useEffect(() => {
    getAllComapny()
  }, [page, size])

  const getAllComapny = async () => {
    setIsLoadingComapny(true)
    try {
      const data: CompanySearch = {
        company_name: companyName,
        company_type: companyType,
        contract_type: contractType,
        phone_no: phoneNo,
      }
      const res = await api.company.getAllCompany(data, page + 1, size)
      setListCompany(res.data.data)
      setTotalElement(res.data.total_elements)
    } catch (error) {
      setListCompany([])
      setTotalElement(0)
      setNotiError(true)
    } finally {
      setIsLoadingComapny(false)
    }
  }

  const handleChangePage = (e: any, newPage: number) => {
    setPage(newPage);
  }

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSize(+event.target.value);
  }

  const onChangeCompanyName = (e: any) => {
    setCompanyName(e.target.value)
  }

  const onChangeContractType = (value: any) => {
    setContracType(value.target.value)
  }

  const onChangeCompanyType = (e: any) => {
    setCompanyType(e.target.value)
  }

  const onChangePhoneNo = (e: any) => {
    setPhoneNo(e.target.value)
  }

  const handleSearch = () => {
    (page === TABLE_PAGE.PAGE) ? getAllComapny() : setPage(TABLE_PAGE.PAGE)
  }

  const handleShowAllStore = (e: any, item: Company) => {
    setIdCompanyActive((id: number) => idCompanyActive && id === item.company_id ? null : item.company_id)
  }

  const _rederSearch = () => {
    return (
      <Box component='div' className='search-form'>
        {_renderSearchInput('company_name', 'Tên công ty', companyName, onChangeCompanyName)}
        {_renderSearchInput('phone_no', 'Số điện thoại', phoneNo, onChangePhoneNo)}
        {_renderSearchSelect('company_type', 'Loại công ty', companyType, COMPANY_TYPE, onChangeCompanyType)}
        {_renderSearchSelect('contract-type', 'Loại hợp đồng', contractType, LIST_CONTRACT_TYPE, onChangeContractType)}
      </Box>
    )
  }

  const _renderSearchInput = (key: string, label: string, value: string, onChange: ChangeEventHandler<HTMLInputElement>) => {
    return (
      <Box component='div' className='text-search' key={key}>{label}
        <Box component='span' className='input-name'>
          <Input value={value} onChange={onChange} />
        </Box>
      </Box>
    )
  }

  const _renderSearchSelect = (key: string, label: string, value: string, listOptions: any[], onChange: any) => {
    return (
      <Box component='div' className='text-search'>{label}
        <Box component='span' className='input-name'>
          <FormControl variant="standard" sx={{ minWidth: 120 }}>
            <Select
              id={key}
              value={value}
              onChange={onChange}
            >
              {listOptions.map(item => (
                <MenuItem value={item.value} key={item.value}>{item.name}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>
      </Box>
    )
  }

  const _renderTableCompany = () => {
    return (
      <TableContainer component={Paper}>
        <Table aria-label="collapsible table">
          <TableHead>
            {_renderTableHeadCompany()}
          </TableHead>
          <TableBody>
            {isLoadingComapny
              ? _renderLoading()
              : listCompany.map((item, index) => _renderTableBodyItemCompany(item, index))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[10, 20, 100]}
          component="div"
          count={totalElement}
          rowsPerPage={size}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    )
  }

  const _renderTableHeadCompany = () => {
    const columnsCompany = [
      { id: 'company_code', label: 'Mã công ty' },
      { id: 'company_name', label: 'Tên công ty' },
      { id: 'company_type', label: 'Loại công ty' },
      { id: 'phone_no', label: 'Số điện thoại' },
      { id: 'city', label: 'Địa chỉ' },
      { id: 'email', label: 'Email' },
      { id: 'created_date', label: 'Ngày tạo' },
    ]
    return (
      <TableRow className='table-title'>
        <TableCell className='row-name' />
        {columnsCompany.map((column) => (
          <TableCell key={column.id} className='row-name'>{column.label}</TableCell>
        ))}
      </TableRow>
    )
  }

  const _renderTableBodyItemCompany = (item: Company, index: number) => {
    return (
      <Fragment key={index}>
        <TableRow sx={{ '& > *': { borderBottom: 'unset' } }} key={index} hover>
          <TableCell>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={(e => handleShowAllStore(e, item))}
              sx={{ zIndex: "1" }}>
              {idCompanyActive === item.company_id ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
            </IconButton>
          </TableCell>
          <TableCell component="th" scope="row" >{item.company_code}</TableCell>
          <TableCell>{item.company_name}</TableCell>
          <TableCell>
            {LIST_COMPANY_TYPE.find((type) => type.type_code === item.company_type)?.type_name}
          </TableCell>
          <TableCell>{item.phone_no}</TableCell>
          <TableCell>{item.city}</TableCell>
          <TableCell>{item.email}</TableCell>
          <TableCell>{moment(item.created_date).format(DATE_UTILS.DATE_LOCAL)}</TableCell>
        </TableRow>

        <TableRow>
          <TableCell sx={{ paddingBottom: 0, paddingTop: 0, textAlign: 'center' }} colSpan={8}>
            <Collapse in={item.company_id === idCompanyActive} timeout="auto" unmountOnExit>
              <TableStore
                idCompanyActive={idCompanyActive}
                onUpdateStore={() => getAllComapny()}
              />
            </Collapse>
          </TableCell>
        </TableRow>

      </Fragment>
    )
  }

  const _renderLoading = () => {
    return (
      <TableRow>
        <TableCell sx={{ paddingBottom: 0, paddingTop: 0, textAlign: 'center' }} colSpan={8}>
          <CircularProgress />
        </TableCell>
      </TableRow>
    )
  }

  return (
    <Box component='div' className='manage-account-container'>
      <Box component='h2'>Company Management</Box>
      {_rederSearch()}
      <Button className='button-search' onClick={handleSearch} >Tìm kiếm</Button>
      {_renderTableCompany()}
      <Snackbar open={notiError} autoHideDuration={3000} onClose={() => setNotiError(false)} anchorOrigin={{ horizontal: 'right', vertical: 'top' }}>
        <Alert onClose={() => setNotiError(false)} severity={'error'} sx={{ width: '100%', marginTop: '70px' }}>
          Không thể lấy được danh sách công ty!
        </Alert>
      </Snackbar>
    </Box>
  )
}