import { Alert, AlertColor, Box, Button, CircularProgress, Input, Modal, Paper, Snackbar, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import moment from "moment";
import { useEffect, useState } from "react";
import api from "src/api";
import { DEPARTMENT, PASSWORD_DEFAULT } from "src/constants";
import { DrgAccount, AccountDelete } from "src/models/account";
import './storeManagement.scss'
import AlertDialog from "../../components/DialogConfirm";
import { DrgStore } from "src/models/store";
import { RootState } from "src/app/store";
import { useSelector } from "react-redux";

type Props = {
  open: boolean,
  close: any,
  handleYes: any,
  storeActive: DrgStore,
}
export type Notification = {
  isNoti: boolean
  notiType: AlertColor,
  notiTitle: string,
}
const initNoti: Notification = {
  isNoti: false,
  notiType: 'success',
  notiTitle: '',
}

export default function ModalStore(props: Props) {
  const { open, close, handleYes, storeActive } = props
  const [isLoadingAccount, setIsLoadingAccount] = useState(false)
  const [listAccountActive, setListAccountActive] = useState([])
  const [accountActive, setAccountActive] = useState<DrgAccount>()
  const [isModalDelete, setIsModalDelete] = useState(false)
  const [notification, setNotification] = useState<Notification>(initNoti)

  useEffect(() => {
    if (storeActive) getAllAccount(storeActive?.drg_store_id)
  }, [storeActive?.drg_store_id])

  const getAllAccount = async (drugId) => {
    setIsLoadingAccount(true)
    try {
      const res = await api.account.getAllAccountInStore(drugId)
      setListAccountActive(res.data)
      setIsLoadingAccount(false)
    }
    catch (error) {
      console.log(error);
      setIsLoadingAccount(false)
    }
  }

  const handleCloseModal = () => {
    setIsModalDelete(false)
  }

  const deleteAccountStore = async (accoutId) => {
    try {
      const dataDelete: AccountDelete = {
        account_id: accoutId,
        active_flg: 0,
        status: 1,
      }
      const res = await api.account.deleteAccount(dataDelete)
      console.log(res);
      getAllAccount(storeActive.drg_store_id)
      setIsModalDelete(false)
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Xóa tài khoản thành công!'
      })
    }
    catch (error) {
      console.log(error);
      setIsModalDelete(false)
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Xóa tài khoản thất bại!'
      })
    }
  }

  const handleActiveAccount = (e: any, value: DrgAccount) => {
    e.stopPropagation()
    activeAccount(value)
  }

  const showModalDelete = (e: any, value: DrgAccount) => {
    e.stopPropagation()
    setIsModalDelete(true)
    setAccountActive(value)
  }

  const closeNotifi = () => {
    setNotification(initNoti)
  }

  const activeAccount = async (account: DrgAccount) => {
    try {
      const dataDelete: AccountDelete = {
        account_id: account.account_id,
        active_flg: 1,
        status: account.status === 1 ? 0 : 1,
      }
      const res = await api.account.deleteAccount(dataDelete)
      getAllAccount(account.drg_store_id)
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Thành công!'
      })
    }
    catch (error) {
      console.log(error)
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Thất bại!'
      })
    }
  }

  const handleResetPassword = (e: any, account: DrgAccount) => {
    e.stopPropagation()
    const params = {
      account_id: account.account_id,
      password: PASSWORD_DEFAULT,
      active_flg: 1,
      status: 1,
    }
    resetPassword(params)
  }
  const resetPassword = async (account: any) => {
    try {
      const res = await api.account.deleteAccount(account)
      console.log(res, 'key')
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Thành công!'
      })
    }
    catch (err) { 
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Thất bại!'
      })
    }
  }

  const _renderItem = (label: string, key: string, property: string) => {
    return (
      <Box component='div' className='info' key={key}>
        <Box component='p' className='info-title'>
          {label}
        </Box>
        <Box component='span'>
          <Input value={storeActive ? property : ''} />
        </Box>
      </Box>
    )
  }

  const _renderTableAccount = () => {
    const listAccount = listAccountActive.filter((item) => item.role_cd !== 'MASTER')
    return (
      <TableContainer component={Paper} className='table-account' sx={{ height: '300px' }}>
        <Table size="small" aria-label="purchases" sx={{ margin: 1 }}>
          <TableHead>
            {_renderTableHeadAccount()}
          </TableHead>
          <TableBody>
            {isLoadingAccount
              ? _renderLoading()
              : listAccount.map((account) => _renderTableBodyAccount(account))
            }
          </TableBody>
        </Table>
      </TableContainer>
    )
  }

  const _renderTableHeadAccount = () => {
    const columnAccounts = [
      { id: 'phone_no', label: 'Số điện thoại', align: 'left' },
      { id: 'account_name', label: 'Tên tài khoản', align: 'left' },
      { id: 'status', label: 'Trạng thái', align: 'left' },
      { id: 'role_cd', label: 'Chức vụ', align: 'left' },
      { id: 'remove', label: 'Xóa', align: 'center' },
      { id: 'active', label: 'Kích hoạt', align: 'center' },
      { id: 'reset_password', label: 'Reset', align: 'center' },
    ]
    return (
      <TableRow className='row-account'>
        {columnAccounts.map((item) => {
          return (
            <TableCell className='text-title' key={item.id} sx={{ textAlign: item.align }}>{item.label}</TableCell>
          )
        })}
      </TableRow>
    )
  }

  const _renderLoading = () => {
    return (
      <TableRow>
        <TableCell sx={{ paddingBottom: 0, paddingTop: 0, textAlign: 'center' }} colSpan={8}>
          <CircularProgress />
        </TableCell>
      </TableRow>
    )
  }

  const _renderTableBodyAccount = (account: DrgAccount) => {
    return (
      <TableRow key={account.account_id}>
        <TableCell >{account.phone_no}</TableCell>
        <TableCell >{account.full_name}</TableCell>
        <TableCell >{account.status === 0
          ? <Box component='p' sx={{ color: 'blue' }}>Chưa kích hoạt</Box>
          : <Box component='p' sx={{ color: 'green' }}>Đã kích hoạt</Box>}
        </TableCell>
        <TableCell >
          {DEPARTMENT.find((item) => item.role === account.role_cd).value}
        </TableCell>
        <TableCell align='center' >
          <Button className='cancel-button' onClick={(e) => showModalDelete(e, account)}>Xóa</Button>
        </TableCell>
        <TableCell align='center'>
          <Button
            className='renew-button'
            onClick={(e) => handleActiveAccount(e, account)}>{account.status === 0 ? 'Kích hoạt' : 'Hủy kích  hoạt'}
          </Button>
        </TableCell>
        <TableCell align='center'>
          <Button
            className='active-button'
            onClick={(e) => handleResetPassword(e, account)}>Đặt lại
          </Button>
        </TableCell>
      </TableRow>
    )
  }

  const _renderContentStore = () => {
    return (
      <Box component='div' className='content'>
        <Box component='div' className='left'>
          {_renderItem('Tên nhà thuốc', 'drg_name', storeActive?.drg_name)}
          {_renderItem('Mã nhà thuốc', 'drg_store_code', storeActive?.drg_store_code)}
          {_renderItem('Số điện thoại', 'phone_no', storeActive?.phone_no)}
        </Box>
        <Box component='div' className='right'>
          {_renderItem('Hạn dùng', 'license_date', moment(storeActive?.license_date, 'YYYYMMDD').format('DD/MM/YYYY'))}
          {_renderItem('Chủ sở hữu', 'owner_name', storeActive?.owner_name)}
          {_renderItem('Tỉnh / Thành phố', 'city', storeActive?.city)}
        </Box>
      </Box>
    )
  }

  const _renderAlert = () => {
    return (
      <Snackbar open={notification.isNoti} autoHideDuration={3000} onClose={closeNotifi} anchorOrigin={{ horizontal: 'right', vertical: 'top' }}>
        <Alert onClose={closeNotifi} severity={notification.notiType} sx={{ width: '100%' }}>
          {notification.notiTitle}
        </Alert>
      </Snackbar>
    )
  }

  const _renderDialog = () => {
    return (
      <AlertDialog
        title='Xóa tài khoản'
        content={`Bạn có chắc chắn xóa tài khoản ${accountActive?.full_name} không?`}
        open={isModalDelete}
        close={handleCloseModal}
        handleNo={handleCloseModal}
        handleYes={() => deleteAccountStore(accountActive?.account_id)}
      />
    )
  }

  return (
    <Modal
      open={open}
      onClose={close}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box component='div' className='popup-modal'>
        <Box component='div' className='title'>Chi tiết nhà thuốc</Box>
        {_renderContentStore()}
        <Box component='h4'>DANH SÁCH TÀI KHOẢN NHÀ THUỐC</Box>
        {_renderTableAccount()}
        <Box component='div' className='group-button'>
          <Box component='button' className='active-button' onClick={handleYes}>Đồng ý</Box>
        </Box>
        {_renderAlert()}
        {_renderDialog()}
      </Box>
    </Modal>
  )
}
