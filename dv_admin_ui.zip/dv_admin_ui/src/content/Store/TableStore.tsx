import { Alert, AlertColor, Button, CircularProgress, Snackbar, Table, TableBody, TableCell, TableHead, TableRow, TextField } from "@mui/material";
import moment from "moment";
import { useEffect, useState } from "react";
import api from "src/api";
import AlertDialog from "src/components/DialogConfirm";
import { DATE_UTILS } from "src/constants";
import { DrgStore, DrgStoreLicense, UpgradePackageType } from "src/models/store";
import ModalCreateStoreLicense from "./ModalCreateStoreLicense";
import ModalStore from "./ModalStore";

export type Notification = {
  isNoti: boolean
  notiType: AlertColor,
  notiTitle: string,
}

const initNoti: Notification = {
  isNoti: false,
  notiType: 'success',
  notiTitle: '',
}

export type Props = {
  idCompanyActive: number
  onUpdateStore: Function
}

const initLicenseStore: DrgStoreLicense = {
  license_id: 0,
  drg_store_id: 0,
  package_id: 1,
  package_code: 'PHARMACY_PRO',
  active_time: '',
  expert_time: '',
  promotion_days: 0,
  days: 0,
  discount: 0,
  fees: 0,
  status: 0,
  created_date: '',
  updated_date: '',
  updated_user: '',
  active_flg: 0,
}

const dateTodayFormat = moment(new Date()).format(DATE_UTILS.YYYYMMDD)

export default function TableStore(props: Props) {
  const { idCompanyActive, onUpdateStore } = props
  const [modalDetailStoreVisible, setModalDetailStoreVisible] = useState(false)
  const [modalDeleteStoreVisible, setModalDeleteStoreVisible] = useState(false)
  const [modalRenewVisible, setModalRenewVisible] = useState(false)
  const [isLoadingStore, setIsLoadingStore] = useState(false)
  const [listStore, setListStore] = useState<DrgStore[]>([])
  const [storeActive, setStoreActive] = useState<DrgStore>()
  const [notification, setNotification] = useState<Notification>(initNoti)
  const [license, setLicense] = useState<DrgStoreLicense>(initLicenseStore)

  useEffect(() => {
    if (idCompanyActive) getAllStoreInCompany()
  }, [idCompanyActive])

  useEffect(() => {
    if (storeActive) getLicenseOfStore()
  }, [storeActive])

  const getLicenseOfStore = async () => {
    try {
      const res = await api.store.getStoreLicense(storeActive.drg_store_id)
      setLicense(res.data)
    } catch {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Không tìm thấy thông tin gói dịch vụ!'
      })
    }
  }

  const getAllStoreInCompany = async () => {
    setIsLoadingStore(true)
    try {
      const res = await api.store.getAllStoreInCompany(idCompanyActive)
      setListStore(res.data)
      setIsLoadingStore(false)
    }
    catch (error) {
      setIsLoadingStore(false)
    }
  }

  const deleteStore = async (drgStoreId: number) => {
    try {
      await api.store.deleteStore(drgStoreId)
      getAllStoreInCompany()
      setModalDeleteStoreVisible(false)
      onUpdateStore()
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Xóa nhà thuốc thành công!'
      })
    } catch (error) {
      setModalDeleteStoreVisible(false)
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Xóa nhà thuốc thất bại!'
      })
    }
  }

  const upgradePackage = async (param: UpgradePackageType) => {
    try {
      await api.store.upgradePackage(param)
      setModalRenewVisible(false)
      getAllStoreInCompany()
      setNotification({
        isNoti: true,
        notiType: 'success',
        notiTitle: 'Gia hạn dịch vụ thành công!'
      })
    }
    catch (err) {
      setNotification({
        isNoti: true,
        notiType: 'error',
        notiTitle: 'Gia hạn dịch vụ không thành công!'
      })
      setModalRenewVisible(false)
    }
  }

  const showDetaiStore = (item: DrgStore) => {
    setModalDetailStoreVisible(true)
    setStoreActive(item)
  }

  const closeNotifi = () => {
    setNotification(initNoti)
  }

  const showModalRenewStore = (e: any, item: DrgStore) => {
    e.stopPropagation()
    setModalRenewVisible(true)
    setStoreActive(item)
  }

  const showModalDeleteStore = (e: any, item: DrgStore) => {
    e.stopPropagation()
    setStoreActive(item)
    setModalDeleteStoreVisible(true)
  }

  const handleCloseModal = () => {
    setModalDetailStoreVisible(false)
    setModalRenewVisible(false)
    setModalDeleteStoreVisible(false)
  }

  const handleSubmitRenew = (param: UpgradePackageType) => {
    if (param.expert_time === 'Invalid date') {
      setModalRenewVisible(false)
      setNotification({
        isNoti: true,
        notiType: 'warning',
        notiTitle: 'Ngày gia hạn chưa hợp lệ'
      })
    }
    else {
      upgradePackage(param)
    }
  }

  const _renderTableHeadStore = () => {
    const columns = [
      { id: 'drg_store_code', label: 'Mã nhà thuốc', align: 'left' },
      { id: 'drg_store_name', label: 'Tên nhà thuốc', align: 'left' },
      { id: 'city', label: 'Địa chỉ', align: 'left' },
      { id: 'phone_no', label: 'Số điện thoại', align: 'left' },
      { id: 'license_date', label: 'Hạn dùng', align: 'left' },
      { id: 'renew', label: 'Gia hạn', align: 'center' },
      { id: 'delete', label: 'Xóa', align: 'center' },
    ]
    return (
      <TableRow className='row-account'>
        {columns.map((item) => {
          return (<TableCell className='text-title' key={item.id} sx={{ textAlign: item.align }}>{item.label}</TableCell>)
        })}
      </TableRow>
    )
  }

  const _renderLoading = () => {
    return (
      <TableRow>
        <TableCell sx={{ paddingBottom: 0, paddingTop: 0, textAlign: 'center' }} colSpan={8}>
          <CircularProgress />
        </TableCell>
      </TableRow>
    )
  }

  const _renderTableBodyRow = (store: DrgStore) => {
    return (
      <TableRow key={store.drg_store_id} onClick={() => showDetaiStore(store)} hover>
        <TableCell component="th" scope="row"> {store.drg_store_code} </TableCell>
        <TableCell >{store.drg_name}</TableCell>
        <TableCell >{store.address1}</TableCell>
        <TableCell >{store.phone_no}</TableCell>
        <TableCell sx={{ color: store.license_date <= dateTodayFormat ? 'red' : 'black' }}>
          {moment(store.license_date, 'YYYYMMDD').format('DD/MM/YYYY')}
        </TableCell>
        <TableCell align='center'>
          <Button className='renew-button' onClick={(e) => showModalRenewStore(e, store)}>Gia hạn</Button>
        </TableCell>
        <TableCell align='center'>
          <Button className='cancel-button' onClick={(e) => showModalDeleteStore(e, store)}>Xóa</Button>
        </TableCell>
      </TableRow>
    )
  }

  return (
    <>
      <Table size="small" aria-label="purchases" sx={{ margin: 1 }}>
        <TableHead>
          {_renderTableHeadStore()}
        </TableHead>
        <TableBody>
          {isLoadingStore && _renderLoading()}
          {listStore.map(store => _renderTableBodyRow(store))}
        </TableBody>
      </Table>

      <ModalStore
        open={modalDetailStoreVisible}
        close={handleCloseModal}
        handleYes={handleCloseModal}
        storeActive={storeActive}
      />

      <AlertDialog
        title='Xóa nhà thuốc'
        content={`Bạn có chắn xóa nhà thuốc: ${storeActive?.drg_name} không?`}
        open={modalDeleteStoreVisible}
        close={handleCloseModal}
        handleNo={handleCloseModal}
        handleYes={() => deleteStore(storeActive?.drg_store_id)}
      />

      {license?.license_id !== 0 &&
        <ModalCreateStoreLicense
          visible={modalRenewVisible}
          license={license}
          storeActive={storeActive}
          handleClose={handleCloseModal}
          handleSubmit={handleSubmitRenew} />}

      <Snackbar open={notification.isNoti} autoHideDuration={3000} onClose={closeNotifi} anchorOrigin={{ horizontal: 'right', vertical: 'top' }}>
        <Alert onClose={closeNotifi} severity={notification.notiType} sx={{ width: '100%', marginTop: '70px' }}>
          {notification.notiTitle}
        </Alert>
      </Snackbar>
    </>
  )
}
