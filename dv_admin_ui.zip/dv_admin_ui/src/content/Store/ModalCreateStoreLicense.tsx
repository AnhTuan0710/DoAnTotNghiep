import { DatePicker } from '@mui/lab'
import { Modal, Box, Button, FormControl, Select, InputAdornment, InputLabel, Input, MenuItem, TextField } from '@mui/material'
import moment from 'moment'
import { useState, useEffect } from 'react'
import { DATE_UTILS, LIST_PACAKGE, PACKAGE_CODE } from 'src/constants'
import { DrgStore, DrgStoreLicense, UpgradePackageType } from 'src/models/store'
import { MoneyFormat, MoneyFormatToNumber } from 'src/utils/money'

type Props = {
  license: DrgStoreLicense
  storeActive: DrgStore
  visible: boolean
  handleClose: () => void
  handleSubmit: (param: UpgradePackageType) => void
}

const ModalCreateStoreLicense = (props: Props) => {
  const { license, storeActive, visible, handleSubmit, handleClose } = props

  const [dateRenew, setDateRenew] = useState(license.expert_time);
  const [packageCode, setPackageCode] = useState(license ? license.package_code : PACKAGE_CODE.PHARMACY_FREE)
  const [dateBonus, setDateBonus] = useState(license ? license.promotion_days : 0)
  const [discount, setDiscount] = useState(license ? license.discount : 0)
  const [fee, setFee] = useState(license ? license.fees : 0)
  const [totalDate, setTotalDate] = useState(0)

  useEffect(() => {
    if (license) countTotalDate()
  }, [dateBonus, license, dateRenew])

  const countTotalDate = () => {
    const exdate = moment(license?.expert_time).format(DATE_UTILS.YYYYMMDD)
    const exDateNew = moment(dateRenew).format(DATE_UTILS.YYYYMMDD)
    const activeDate = moment(license?.active_time).format(DATE_UTILS.YYYYMMDD)
    setTotalDate(Number(dateRenew === '' || dateRenew.toString() === 'Invalid date' ? exdate : exDateNew) - Number(activeDate))
  }

  const handleSubmitRenew = () => {
    const param: UpgradePackageType = {
      drg_store_id: storeActive.drg_store_id,
      package_code: packageCode,
      expert_time: moment(dateRenew).format(),
      days: totalDate,
      fees: fee ? fee : license.fees ? license.fees : 0,
      promotion_days: dateBonus ? dateBonus : license.promotion_days ? license.promotion_days : 0,
      discount: discount ? discount : license.discount ? license.discount : 0,
    }
    handleSubmit(param)
  }

  const handleChangePackage = (value: string) => {
    setPackageCode(value)
  }

  const onChangeDate = (newValue: Date) => {
    setDateRenew(moment(newValue).format())
  }

  const _renderItemInfo = (label: string, key: string, value: string, disabled?: boolean, unit?: string, onChange?: any,) => {
    return (
      <FormControl sx={{ m: 1 }} variant="standard" key={key} fullWidth>
        <InputLabel htmlFor="standard-adornment-amount">{label}</InputLabel>
        <Input
          value={storeActive ? value : ''}
          disabled={disabled}
          onChange={onChange}
          endAdornment={<InputAdornment position="end">{unit}</InputAdornment>}
        />
      </FormControl>
    )
  }

  const _renderDatePicker = (label: string, value: string, onChange: (date: Date) => void) => {
    return (
      <DatePicker
        value={value}
        label={label}
        disablePast={true}
        inputFormat={'dd/MM/yyyy'}
        onChange={onChange}
        renderInput={(params) =>
          <TextField fullWidth {...params} variant='standard' sx={{ m: 1 }} />}
      />
    )
  }

  const _renderInputNumber = (label: string, key: string, value: number, disabled?: boolean, unit?: string, onChange?: any) => {
    return (
      <FormControl sx={{ m: 1 }} variant="standard" key={key} fullWidth>
        <InputLabel htmlFor="standard-adornment-amount">{label}</InputLabel>
        <Input
          value={MoneyFormat(value)}
          disabled={disabled}
          onChange={onChange}
          endAdornment={<InputAdornment position="end">{unit}</InputAdornment>}
        />
      </FormControl>
    )
  }

  const _renderSelectPackage = () => {
    return (
      <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
        <InputLabel>Gói dịch vụ mới</InputLabel>
        <Select
          value={packageCode}
          onChange={(e: any) => handleChangePackage(e.target.value)}
          label="Gói dịch vụ mới"
        >
          {LIST_PACAKGE.map((item, index) =>
            <MenuItem value={item.package_code} key={index}
              disabled={item.package_code === PACKAGE_CODE.PHARMACY_FREE}
            >{item.package_name}
            </MenuItem>
          )}
        </Select>
      </FormControl>
    )
  }

  const _renderContentModalRenew = () => {
    return (
      <Box component='div' className='content'>
        <Box component='div' className='left' sx={{ width: '50%' }}>
          {_renderItemInfo('Mã nhà thuốc:', 'drg_store_code', storeActive?.drg_store_code, true,)}
          {_renderItemInfo('Tên nhà thuốc:', 'drg_name', storeActive?.drg_name, true,)}
          {_renderItemInfo('Số điện thoại:', 'phone_no', storeActive?.phone_no, true,)}
          {_renderSelectPackage()}
          <Box className="div" sx={{ m: 1 }}>Tổng số ngày: <Box component={'span'} style={{ color: 'red' }}>{totalDate}</Box> ngày</Box>
        </Box>
        <Box component='div' className='right' sx={{ width: '50%' }}>
          {_renderInputNumber('Chiết khấu:', 'discount', discount, false, 'VNĐ', (e) => setDiscount(MoneyFormatToNumber(e.target.value)))}
          {_renderInputNumber('Phí dịch vụ:', 'fee', fee, false, 'VNĐ', (e) => setFee(MoneyFormatToNumber(e.target.value)))}
          {_renderInputNumber('Số ngày thêm:', 'promotionDate', dateBonus, false, 'Ngày', (e) => setDateBonus(MoneyFormatToNumber(e.target.value)))}
          {_renderDatePicker('Hạn dùng:', dateRenew, onChangeDate)}
        </Box>
      </Box>
    )
  }

  return (
    <Modal
      open={visible}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box component='div' className='popup-modal' sx={{ width: "50%" }}>
        <Box component='div' className='title'>Gia hạn nhà thuốc</Box>
        {_renderContentModalRenew()}
        <Box component='div' className='group-button'>
          <Button className='active-button' onClick={handleSubmitRenew}>Xác nhận</Button>
          <Button className='cancel-button' onClick={handleClose} sx={{ marginLeft: '10px' }}>Hủy</Button>
        </Box>
      </Box>
    </Modal>
  )
}

export default ModalCreateStoreLicense