export type RechargeWalletRequest = {
  wallet_id: number,
  amount: number
}
