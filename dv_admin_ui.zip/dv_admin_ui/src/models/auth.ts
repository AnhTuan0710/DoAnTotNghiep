export interface LoginRequest {
    username?: string;
    password?: string;
    refresh_token?: string;
    grant_type?: string;
  }