export interface ReportActivityResponse {
  drg_store_id: number
  drg_store_code: string
  drg_name: string
  city: string
  district: string
  address1: string
  phone_no: string
  total_activity: number
}

export interface ReportActivityRequest {
  from_time: string
  to_time: string
  activity_type: string
  drg_name: string
}

export interface DrgActivity {
  activity_id: number
  account_id: number
  drg_store_id: number
  activity_type: string
  content_activity: string
  created_date: string
  updated_date: string
  updated_user: string
  active_flg: number
}
