export interface DataCounty {
    data: DataProvince[]
    data_data: string
    generate_date: number
    stats: {
        elapsed_time: number
        level1_count: number
        level2_count: number
        level3_count: number
    }
}

export interface DataProvince {
    level1_id: string
    level2s: DataDitrict[]
    name: string
    type: string
}

export interface DataDitrict {
    level2_id: string
    name: string
    type: string
    level3s: DataWards[]
}

export interface DataWards {
    level3_id: string
    name: string
    type: string
}