export type StoreSearch = {
  drg_name: string,
  login_id: string,
  contract_type: string
}
export type DrgStore = {
  drg_store_id: number,
  drg_store_code: string,
  drg_tax_code: string | null,
  drg_name: string,
  drg_type: number,
  master_flg: number,
  description: string | null,
  prefecture: string | null,
  city: string | null,
  district: string | null,
  address1: string | null,
  address2: string | null,
  zipcode: string | null,
  email: string,
  facebook_id: string | null,
  gpp_flg: number,
  phone_no: string,
  pharmacist_number: string | null,
  avatar_url: string | null,
  company_id: number,
  company_code: string | null,
  company_name: string | null,
  company_type: string,
  owner_name: string | null,
  tax_no: string | null,
  tax_method: string | null,
  open_date: string | null,
  contract_url: string | null,
  expired_alarm: string | null,
  source: string | null,
  anonymous_cus_id: string | null,
  id_num: string | null,
  business_license: string | null,
  ref_user: string | null,
  store_status: string,
  debt_account: string | null,
  ref_password: string | null,
  ref_account: string | null,
  created_date: string,
  updated_date: string,
  updated_user: string | null,
  active_flg: number,
  ref_gpp: boolean,
  license_date: string
}

export type RenewStore = {
  license_date: string,
  drg_store_id: number,
}

export type DrgStoreLicense = {
  license_id: number
  drg_store_id: number
  package_id: number
  package_code: string
  active_time: string
  expert_time: string
  promotion_days: number
  days: number
  discount: number
  fees: number
  status: number
  created_date: string
  updated_date: string
  updated_user: string
  active_flg: number
}

export type UpgradePackageType = {
  drg_store_id: number,
  package_code: string,
  expert_time: string,
  days: number,
  fees: number,
  promotion_days?: number,
  discount?: number,
}