export interface SmsTemplateData {
  ref_company_id: number;
  ref_channel_name: string;
  channel_code: string;
  template_name: string;
  template_type: string;
  template_content: string;
  template_fns_id?: number;
  template_zalo_id?: number;
  template_sms_link_id?: string;
  status?: number;
  updated_user?: string;
  template_params: SmsTemplateParams[];
}

export interface SmsTemplateParams {
  name: string;
  type: string;
  max_length: number;
  is_require: 0 | 1;
}
