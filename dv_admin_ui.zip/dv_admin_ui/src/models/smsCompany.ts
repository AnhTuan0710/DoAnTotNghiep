export type SmsCompanySearch = {
  company_name: string,
  company_type: string,
  phone_no: string,
}

export type SmsCompany = {
  active_flg: number,
  company_code: string,
  company_id: number,
  company_name: string,
  company_type: string,
  created_date: string,
  email: string,
  phone_no: string,
  ref_company_id: number,
  updated_date: string,
  updated_user: string,
}

export type SmsBrandname = {
  active_flg: number,
  brand_id: number,
  brand_name: string,
  channel_code: string,
  client_id: string,
  client_secret: string,
  created_date: string,
  ref_company_id: number,
  scope: string,
  status: number,
  updated_date: string,
  updated_user: string
}

export type SmsZalo = {
  active_flg: number,
  app_id: string,
  channel_code: string,
  created_date: string,
  ref_company_id: number,
  secret_key: string,
  status: number,
  updated_date: string,
  updated_user: string,
  zalo_id: number,
  zalo_oa_id: string,
  zalo_oa_name: string
}

export type SmsPriceList = {
  active_flg: number,
  created_date: string,
  price_ads_gmobile: number,
  price_ads_mobi: number,
  price_ads_vietnam: number,
  price_ads_viettel: number,
  price_ads_vina: number,
  price_cs_gmobile: number,
  price_cs_itelecom: number,
  price_cs_mobi: number,
  price_cs_vietnam: number,
  price_cs_viettel: number,
  price_cs_vina: number,
  price_cs_zalo: number,
  price_list_id: number,
  ref_company_id: number,
  status: number,
  updated_date: string,
  updated_user: string,
}

export type SmsCashflow = {
  from_time: string,
  to_time: string,
  cashflow_type: string
}

export type SmsPriceListRequest = {
  ref_company_id: number,
  price_ads_mobi: number,
  price_ads_vina: number,
  price_ads_viettel: number,
  price_ads_vietnam: number,
  price_ads_gmobile: number,
  price_cs_mobi: number,
  price_cs_vina: number,
  price_cs_viettel: number,
  price_cs_vietnam: number,
  price_cs_gmobile: number,
  price_cs_itelecom: number,
  price_cs_zalo: number
}

export type SmsTemplateResponse = {
  active_flg: number,
  apply_template_quota: boolean
  channel_code: string,
  created_date: string,
  preview_url: string,
  price: number,
  ref_channel_name: string,
  ref_company_id: number,
  status: number,
  template_content: string,
  template_daily_quota: boolean
  template_fns_id: number,
  template_id: number,
  template_name: string,
  template_quantity: string,
  template_remaining_quota: boolean
  template_sms_link_id: number
  template_tag: string,
  template_type: string,
  template_zalo_id: number,
  time_out: string,
  updated_date: string,
  updated_user: string,
}
